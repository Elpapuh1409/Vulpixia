# 🎨 Guía de Personalización - Vulpixia

Esta guía te ayudará a personalizar Vulpixia según tus necesidades.

## 🌈 Cambiar Paleta de Colores

Edita `assets/css/style.css` en la sección `:root`:

```css
:root {
    --primary-color: #8B5CF6;      /* Morado */
    --secondary-color: #EC4899;    /* Rosa */
    --dark-bg: #0F172A;            /* Azul oscuro */
    --dark-card: #1E293B;          /* Gris oscuro */
    --light-bg: #F8FAFC;           /* Gris claro */
    --text-dark: #1E293B;          /* Texto oscuro */
    --text-light: #64748B;         /* Texto claro */
    --text-white: #FFFFFF;         /* Blanco */
    --accent-pink: #F05FCC;        /* Rosa neón */
    --accent-blue: #3B82F6;        /* Azul */
}
```

### Ejemplos de Paletas Alternativas:

**Paleta Verde y Azul:**
```css
--primary-color: #10B981;          /* Verde */
--secondary-color: #3B82F6;        /* Azul */
--accent-pink: #06B6D4;            /* Cyan */
```

**Paleta Roja y Naranja:**
```css
--primary-color: #EF4444;          /* Rojo */
--secondary-color: #F97316;        /* Naranja */
--accent-pink: #FCA5A5;            /* Rojo claro */
```

**Paleta Morada Oscura:**
```css
--primary-color: #6D28D9;          /* Morado oscuro */
--secondary-color: #9333EA;        /* Violeta */
--accent-pink: #C084FC;            /* Morado claro */
```

## 📝 Cambiar Textos

### Logo y Nombre de Sitio
En `index.html`, busca:
```html
<div class="logo">
    <i class="fas fa-fox"></i>
    <span>Vulpixia</span>  <!-- Cambiar aquí -->
</div>
```

### Títulos y Secciones
Busca las etiquetas `<h1>`, `<h2>`, `<p>` en los archivos HTML y edita el contenido.

Ejemplo:
```html
<!-- Antes -->
<h1 class="hero-title">Encuentra el talento ideal para tu próximo proyecto</h1>

<!-- Después -->
<h1 class="hero-title">Tu título personalizado aquí</h1>
```

## 🎯 Agregar Categorías Nuevas

En `index.html`, busca la sección de categorías y agrega:

```html
<div class="category-card">
    <div class="category-icon">
        <i class="fas fa-icon-name"></i>  <!-- Cambiar icono -->
    </div>
    <h3>Tu Categoría</h3>
    <p>Descripción de tu categoría</p>
    <a href="#" class="btn-link">Ver freelancers <i class="fas fa-arrow-right"></i></a>
</div>
```

**Iconos disponibles:** Usa cualquiera de [Font Awesome](https://fontawesome.com)

## 👥 Agregar Freelancers a la Galería

En `index.html`, busca la sección "Freelancers Destacados":

```html
<div class="freelancer-card">
    <div class="card-header">
        <img src="https://i.pravatar.cc/400?img=1" alt="Nombre" class="avatar">
        <div class="rating">
            <i class="fas fa-star"></i>
            <span>5.0</span>
        </div>
    </div>
    <div class="card-body">
        <h3>Tu Nombre</h3>
        <p class="specialty">Tu Especialidad</p>
        <div class="price">Desde <strong>$XX/hr</strong></div>
        <div class="skills">
            <span class="skill-tag">Habilidad1</span>
            <span class="skill-tag">Habilidad2</span>
            <span class="skill-tag">Habilidad3</span>
        </div>
    </div>
    <div class="card-footer">
        <a href="pages/freelancer-profile.html?id=X" class="btn btn-outline btn-small">Ver perfil</a>
        <a href="#" class="btn btn-primary btn-small">Contactar</a>
    </div>
</div>
```

## 🔗 Cambiar Enlaces

En `header.html` y `footer.html`, actualiza los enlaces:

```html
<!-- Antes -->
<a href="#contacto" class="nav-link">Contacto</a>

<!-- Después -->
<a href="https://tu-dominio.com/contacto" class="nav-link">Contacto</a>
```

## 🎬 Cambiar Imágenes

### Avatar de Perfil
Usa [Pravatar](https://i.pravatar.cc/) o tu propio servidor:

```html
<!-- Cambiar número para diferente avatar -->
<img src="https://i.pravatar.cc/400?img=1" alt="Usuario">

<!-- O usar tu propia imagen -->
<img src="assets/images/mi-foto.jpg" alt="Usuario">
```

### Imágenes de Portafolio
En `freelancer-profile.html`:

```html
<img src="https://via.placeholder.com/200x150?text=Mi+Proyecto" alt="Proyecto">

<!-- O -->
<img src="assets/images/proyecto1.jpg" alt="Proyecto">
```

## 📧 Cambiar Email de Contacto

En `backend/config.php`:

```php
define('MAIL_FROM', 'mi-email@ejemplo.com');
define('MAIL_FROM_NAME', 'Mi Nombre');
```

## 🗣️ Cambiar Idioma

Para traducir al inglés o otro idioma:

1. Crea un archivo `assets/js/lang.js`
2. Define los textos en diferentes idiomas
3. Usa JavaScript para cambiar según el idioma seleccionado

Ejemplo básico:
```javascript
const translations = {
    es: {
        heroTitle: "Encuentra el talento ideal",
        heroSubtitle: "Conecta con freelancers creativos..."
    },
    en: {
        heroTitle: "Find the ideal talent",
        heroSubtitle: "Connect with creative freelancers..."
    }
};
```

## 🔐 Configurar HTTPS

En `backend/config.php`, cambia el URL:

```php
// De:
define('SITE_URL', 'http://localhost/vulpixia/');

// A:
define('SITE_URL', 'https://tudominio.com/vulpixia/');
```

## 💾 Personalizar la Base de Datos

En `backend/database.sql`, puedes:

1. Cambiar nombres de tablas
2. Agregar campos adicionales
3. Cambiar tipos de datos
4. Agregar más categorías

Ejemplo: Agregar categoría nueva
```sql
INSERT INTO categorias (nombre, icono) VALUES ('Mi Categoría', 'fa-icono');
```

## 📱 Cambiar Breakpoints Responsivos

En `assets/css/style.css`, busca `@media`:

```css
/* Tablet */
@media (max-width: 768px) {
    /* Estilos para tablets */
}

/* Móvil */
@media (max-width: 480px) {
    /* Estilos para móviles */
}
```

Puedes ajustar los valores según tus necesidades.

## 🎨 Agregar Nuevas Fuentes

En el `<head>` de `index.html`:

```html
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
```

Luego en `style.css`:

```css
body {
    font-family: 'Poppins', 'Segoe UI', sans-serif;
}
```

## 🌙 Agregar Dark Mode

En `assets/js/script.js`:

```javascript
function toggleDarkMode() {
    document.documentElement.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.documentElement.classList.contains('dark-mode'));
}

// Cargar preferencia al iniciar
if (localStorage.getItem('darkMode') === 'true') {
    document.documentElement.classList.add('dark-mode');
}
```

## 🔔 Agregar Notificaciones

En `assets/js/script.js`:

```javascript
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => notification.remove(), 3000);
}
```

## 📊 Agregar Analytics

En `index.html`, antes de `</body>`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'GA_ID');
</script>
```

## 🔍 SEO y Meta Tags

En `index.html`, modifica en el `<head>`:

```html
<meta name="description" content="Tu descripción aquí">
<meta name="keywords" content="freelancer, servicios, marketplace">
<meta name="author" content="Tu Nombre">
<meta property="og:title" content="Vulpixia">
<meta property="og:description" content="Tu descripción">
<meta property="og:image" content="tu-imagen.jpg">
```

## 🎯 Crear Página de Términos y Condiciones

1. Crea `pages/terms.html`
2. Enlázalo en footer
3. Agrega el contenido legal

## 📄 Crear Política de Privacidad

1. Crea `pages/privacy.html`
2. Agrega la política
3. Enlázalo en footer

## ✉️ Formulario de Newsletter

Agrega a `index.html`:

```html
<form class="newsletter-form">
    <input type="email" placeholder="Tu email">
    <button type="submit" class="btn btn-primary">Suscribirse</button>
</form>
```

---

## 🎓 Recursos Útiles

- [Font Awesome Icons](https://fontawesome.com)
- [Google Fonts](https://fonts.google.com)
- [Color Palette Generator](https://coolors.co)
- [CSS Gradients](https://www.gradient-generator.com)

## 💡 Tips de Diseño

1. **Consistencia:** Mantén los colores consistentes
2. **Espaciado:** Usa espacios amplios
3. **Tipografía:** No uses más de 2-3 fuentes
4. **Iconos:** Usa Font Awesome para consistencia
5. **Responsive:** Prueba en móvil constantemente

---

**¡Personaliza tu Vulpixia!** 🚀
