/**
 * CHATBOT VULPIXIA
 * Widget flotante con backend PHP opcional y fallback local en el navegador.
 */

class ChatbotVulpixia {
    constructor() {
        this.chatContainer = null;
        this.messagesContainer = null;
        this.isOpen = false;
        this.conversationId = null;
        this.messages = [];
        this.isLoading = false;
        this.storageKey = '';

        this.init();
    }

    init() {
        this.prepareConversation();
        this.createChatbot();
        this.attachEventListeners();
        this.loadConversationHistory();
    }

    prepareConversation() {
        const storedId = localStorage.getItem('chatbot_conversation_id');
        this.conversationId = storedId || `conv_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
        localStorage.setItem('chatbot_conversation_id', this.conversationId);
        this.storageKey = `chatbot_history_${this.conversationId}`;
    }

    createChatbot() {
        if (document.getElementById('vulpixia-chatbot')) return;

        const chatbotHTML = `
            <div id="vulpixia-chatbot" class="vulpixia-chatbot">
                <button id="chatbot-toggle" class="chatbot-toggle" title="Abrir asistente" aria-label="Abrir asistente" aria-expanded="false">
                    <i class="fas fa-robot"></i>
                    <span class="badge" aria-hidden="true">1</span>
                </button>

                <div id="chatbot-window" class="chatbot-window hidden" role="dialog" aria-label="Asistente Vulpixia">
                    <div class="chatbot-header">
                        <div class="chatbot-title">
                            <i class="fas fa-robot"></i>
                            <h3>Asistente Vulpixia</h3>
                        </div>
                        <div class="chatbot-actions">
                            <button id="chatbot-clear" class="chatbot-action-btn" title="Limpiar chat" aria-label="Limpiar chat">
                                <i class="fas fa-trash"></i>
                            </button>
                            <button id="chatbot-close" class="chatbot-action-btn" title="Cerrar" aria-label="Cerrar chat">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>

                    <div id="chatbot-messages" class="chatbot-messages" aria-live="polite"></div>

                    <div id="chatbot-suggestions" class="chatbot-suggestions" aria-label="Preguntas rápidas">
                        <button class="suggestion-btn" type="button" data-suggestion="Necesito encontrar un freelancer">
                            Buscar freelancer
                        </button>
                        <button class="suggestion-btn" type="button" data-suggestion="Quiero ver los planes de Vulpixia">
                            Planes premium
                        </button>
                        <button class="suggestion-btn" type="button" data-suggestion="Cómo funciona Vulpixia">
                            Cómo funciona
                        </button>
                        <button class="suggestion-btn" type="button" data-suggestion="Necesito soporte">
                            Contactar soporte
                        </button>
                    </div>

                    <div class="chatbot-input-area">
                        <form id="chatbot-form" class="chatbot-form">
                            <input
                                type="text"
                                id="chatbot-input"
                                placeholder="Escribe tu pregunta aquí..."
                                autocomplete="off"
                                maxlength="500"
                                aria-label="Mensaje para el asistente"
                            >
                            <button type="submit" id="chatbot-send" class="chatbot-send-btn" title="Enviar" aria-label="Enviar mensaje">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>

                    <div id="chatbot-typing" class="chatbot-typing hidden" aria-hidden="true">
                        <div class="typing-indicator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
        this.chatContainer = document.getElementById('chatbot-window');
        this.messagesContainer = document.getElementById('chatbot-messages');
    }

    attachEventListeners() {
        document.getElementById('chatbot-toggle').addEventListener('click', () => this.toggleChat());
        document.getElementById('chatbot-close').addEventListener('click', () => this.closeChat());
        document.getElementById('chatbot-clear').addEventListener('click', () => this.clearChat());

        document.getElementById('chatbot-form').addEventListener('submit', (event) => {
            event.preventDefault();
            this.sendMessage();
        });

        document.querySelectorAll('.suggestion-btn').forEach((button) => {
            button.addEventListener('click', (event) => {
                const message = event.currentTarget.dataset.suggestion;
                document.getElementById('chatbot-input').value = message;
                this.sendMessage();
            });
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape' && this.isOpen) {
                this.closeChat();
            }
        });
    }

    toggleChat() {
        this.isOpen ? this.closeChat() : this.openChat();
    }

    openChat() {
        this.chatContainer.classList.remove('hidden');
        document.getElementById('chatbot-toggle').classList.add('active');
        document.getElementById('chatbot-toggle').setAttribute('aria-expanded', 'true');
        document.querySelector('.chatbot-toggle .badge')?.classList.add('hidden');
        document.getElementById('chatbot-input').focus();
        this.isOpen = true;
        this.scrollToBottom();
    }

    closeChat() {
        this.chatContainer.classList.add('hidden');
        document.getElementById('chatbot-toggle').classList.remove('active');
        document.getElementById('chatbot-toggle').setAttribute('aria-expanded', 'false');
        this.isOpen = false;
    }

    clearChat() {
        if (!confirm('¿Deseas borrar el historial del chat?')) return;

        this.messages = [];
        localStorage.removeItem(this.storageKey);
        this.renderWelcomeMessage('Chat limpiado. ¿En qué puedo ayudarte?');
    }

    sendMessage() {
        const input = document.getElementById('chatbot-input');
        const message = input.value.trim();

        if (!message || this.isLoading) return;

        this.addMessage(message, 'user');
        input.value = '';
        this.getAIResponse(message);
    }

    addMessage(content, sender = 'bot', options = {}) {
        const settings = typeof options === 'boolean' ? { formatted: options } : options;
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('chatbot-message', sender === 'user' ? 'user-message' : 'bot-message');

        const avatar = document.createElement('div');
        avatar.classList.add('message-avatar');
        avatar.innerHTML = sender === 'user'
            ? '<i class="fas fa-user"></i>'
            : '<i class="fas fa-robot"></i>';

        const contentDiv = document.createElement('div');
        contentDiv.classList.add('message-content');
        contentDiv.innerHTML = settings.formatted
            ? this.sanitizeFormattedHtml(content)
            : `<p>${this.escapeHtml(content)}</p>`;

        messageDiv.appendChild(avatar);
        messageDiv.appendChild(contentDiv);
        this.messagesContainer.appendChild(messageDiv);

        if (settings.save !== false) {
            this.messages.push({
                sender,
                content,
                formatted: Boolean(settings.formatted),
                timestamp: new Date().toISOString()
            });
            this.saveConversationHistory();
        }

        this.scrollToBottom();
    }

    async getAIResponse(userMessage) {
        this.setLoading(true);

        try {
            const response = await fetch('backend/chatbot.php?action=send_message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'send_message',
                    message: userMessage,
                    conversation_id: this.conversationId,
                    history: this.messages.slice(-8)
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const payload = await response.json();
            const data = payload.data || {};

            if (payload.status === 'success' && data.response) {
                window.setTimeout(() => {
                    this.addMessage(data.response, 'bot', { formatted: Boolean(data.formatted) });
                }, 250);
                return;
            }

            throw new Error(payload.message || 'Respuesta inválida del servidor');
        } catch (error) {
            console.warn('Chatbot backend no disponible, usando respuesta local:', error);
            const fallback = this.generateLocalResponse(userMessage);
            window.setTimeout(() => {
                this.addMessage(fallback.text, 'bot', { formatted: fallback.formatted });
            }, 250);
        } finally {
            this.setLoading(false);
        }
    }

    setLoading(isLoading) {
        this.isLoading = isLoading;
        document.getElementById('chatbot-send').disabled = isLoading;
        document.getElementById('chatbot-input').disabled = isLoading;

        if (isLoading) {
            this.showTypingIndicator();
        } else {
            this.hideTypingIndicator();
            document.getElementById('chatbot-input').focus();
        }
    }

    generateLocalResponse(message) {
        const text = this.normalizeText(message);

        if (this.includesAny(text, ['hola', 'buenos dias', 'buenas tardes', 'buenas noches', 'hey'])) {
            return {
                text: '¡Hola! Soy el asistente de Vulpixia. Puedo ayudarte a encontrar freelancers, entender los planes o resolver dudas sobre la plataforma.',
                formatted: false
            };
        }

        if (this.includesAny(text, ['buscar', 'encontrar', 'freelancer', 'programador', 'desarrollador', 'disenador', 'editor', 'traductor', 'redactor', 'necesito'])) {
            return {
                text: "Puedo ayudarte a encontrar talento. Revisa estas opciones:\n\n- <a href='pages/ranking.html'>Ver ranking de freelancers</a>\n- <a href='#freelancers'>Explorar perfiles destacados</a>\n\nSi me dices la categoría, presupuesto y plazo, puedo orientarte mejor.",
                formatted: true
            };
        }

        if (this.includesAny(text, ['plan', 'planes', 'precio', 'costo', 'premium', 'membresia', 'suscripcion', 'gratis'])) {
            return {
                text: "Estos son los planes principales:\n\n**Básico:** gratis para empezar.\n**Profesional:** más proyectos y propuestas.\n**Premium:** mayor alcance y almacenamiento.\n**Empresarial:** límites amplios y soporte dedicado.\n\n<a href='pages/memberships.html'>Ver todos los planes</a>",
                formatted: true
            };
        }

        if (this.includesAny(text, ['como funciona', 'como se usa', 'pasos', 'guia', 'proceso'])) {
            return {
                text: "Vulpixia funciona en tres pasos:\n\n1. Regístrate como cliente o freelancer.\n2. Busca talento, publica proyectos o envía propuestas.\n3. Contacta, acuerda los detalles y trabaja con seguimiento.\n\n<a href='#como-funciona'>Ver la sección Cómo funciona</a>",
                formatted: true
            };
        }

        if (this.includesAny(text, ['cuenta', 'registro', 'registrarme', 'login', 'iniciar sesion', 'perfil'])) {
            return {
                text: "Para gestionar tu cuenta puedes usar estos accesos:\n\n- <a href='pages/register.html'>Crear cuenta</a>\n- <a href='pages/login.html'>Iniciar sesión</a>\n\nTambién puedes elegir si entras como cliente o freelancer desde el registro.",
                formatted: true
            };
        }

        if (this.includesAny(text, ['soporte', 'ayuda', 'contacto', 'problema', 'error'])) {
            return {
                text: "Puedes escribir desde el formulario de contacto al final de la página. También puedo ayudarte aquí si me cuentas qué problema tienes y en qué paso aparece.",
                formatted: false
            };
        }

        if (this.includesAny(text, ['gracias', 'muchas gracias'])) {
            return {
                text: '¡Con gusto! Estoy aquí cuando necesites otra mano con Vulpixia.',
                formatted: false
            };
        }

        return {
            text: 'Puedo ayudarte con búsqueda de freelancers, planes, registro, proyectos y soporte. Cuéntame un poco más de lo que necesitas y te guío.',
            formatted: false
        };
    }

    includesAny(text, keywords) {
        return keywords.some((keyword) => text.includes(keyword));
    }

    normalizeText(text) {
        return text
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '');
    }

    showTypingIndicator() {
        document.getElementById('chatbot-typing').classList.remove('hidden');
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        document.getElementById('chatbot-typing').classList.add('hidden');
    }

    saveConversationHistory() {
        localStorage.setItem(this.storageKey, JSON.stringify(this.messages.slice(-60)));
    }

    loadConversationHistory() {
        const history = localStorage.getItem(this.storageKey);

        if (!history) {
            this.renderWelcomeMessage();
            return;
        }

        try {
            this.messages = JSON.parse(history);
            this.messagesContainer.innerHTML = '';

            if (!this.messages.length) {
                this.renderWelcomeMessage();
                return;
            }

            this.messages.forEach((message) => {
                this.addMessage(message.content, message.sender, {
                    formatted: Boolean(message.formatted),
                    save: false
                });
            });
        } catch (error) {
            console.error('Error cargando historial del chatbot:', error);
            localStorage.removeItem(this.storageKey);
            this.renderWelcomeMessage();
        }
    }

    renderWelcomeMessage(customText = '') {
        this.messagesContainer.innerHTML = '';
        const welcome = customText || "¡Hola! Soy tu asistente de Vulpixia.\n\nPuedo ayudarte a:\n\n- Encontrar freelancers ideales\n- Consultar planes y precios\n- Entender cómo funciona la plataforma\n- Resolver dudas de soporte\n\n¿En qué puedo ayudarte hoy?";
        this.addMessage(welcome, 'bot', { formatted: true, save: false });
    }

    sanitizeFormattedHtml(content) {
        const template = document.createElement('template');
        let html = this.escapeHtml(content)
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/^- (.*)$/gm, '<li>$1</li>')
            .replace(/\n/g, '<br>');

        html = html.replace(/&lt;a\s+href=(?:&quot;|&#039;|'|")(.*?)(?:&quot;|&#039;|'|")(?:\s+.*?)?&gt;(.*?)&lt;\/a&gt;/gi, (_match, href, label) => {
            const safeHref = this.sanitizeHref(href);
            return safeHref ? `<a href="${safeHref}">${label}</a>` : label;
        });

        template.innerHTML = html;

        template.content.querySelectorAll('a').forEach((link) => {
            const safeHref = this.sanitizeHref(link.getAttribute('href') || '');
            if (!safeHref) {
                link.replaceWith(document.createTextNode(link.textContent || ''));
                return;
            }

            link.setAttribute('href', safeHref);
            link.setAttribute('rel', 'noopener noreferrer');
            if (!safeHref.startsWith('#')) {
                link.setAttribute('target', '_blank');
            }
        });

        return template.innerHTML;
    }

    sanitizeHref(href) {
        const value = href.trim();
        const isAllowed = value.startsWith('#')
            || value.startsWith('pages/')
            || value.startsWith('index.html')
            || value.startsWith('./')
            || value.startsWith('/');

        return isAllowed ? this.escapeAttribute(value) : '';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = String(text);
        return div.innerHTML;
    }

    escapeAttribute(text) {
        return String(text).replace(/"/g, '&quot;');
    }

    scrollToBottom() {
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.vulpixiaChatbot = new ChatbotVulpixia();
});
