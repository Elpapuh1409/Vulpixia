/* =====================
   JAVASCRIPT INTERACTIVO
   ===================== */

// Elementos del DOM
const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
const contactForm = document.getElementById('contactForm');

// =====================
// MENÚ RESPONSIVO
// =====================
let menuOpen = false;

menuToggle?.addEventListener('click', () => {
    menuOpen = !menuOpen;
    
    if (menuOpen) {
        nav.style.display = 'flex';
        nav.style.position = 'absolute';
        nav.style.top = '60px';
        nav.style.left = '0';
        nav.style.right = '0';
        nav.style.flexDirection = 'column';
        nav.style.backgroundColor = 'white';
        nav.style.borderBottom = '1px solid #E2E8F0';
        nav.style.padding = '1rem';
        nav.style.gap = '1rem';
        menuToggle.innerHTML = '<i class="fas fa-times"></i>';
    } else {
        nav.style.display = '';
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    }
});

// Cerrar menú al hacer click en un link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        menuOpen = false;
        nav.style.display = '';
        menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    });
});

// =====================
// FORMULARIO DE CONTACTO
// =====================
contactForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const formData = new FormData(contactForm);
    const data = Object.fromEntries(formData);
    
    // Validación básica
    if (data.nombre && data.correo && data.mensaje) {
        console.log('Formulario enviado:', data);
        
        // Mostrar mensaje de éxito
        const successMsg = document.createElement('div');
        successMsg.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #10B981;
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            z-index: 9999;
            animation: slideIn 0.3s ease-out;
        `;
        successMsg.textContent = '✓ Mensaje enviado correctamente';
        document.body.appendChild(successMsg);
        
        // Limpiar formulario
        contactForm.reset();
        
        // Eliminar mensaje después de 3 segundos
        setTimeout(() => {
            successMsg.remove();
        }, 3000);
    }
});

// =====================
// ANIMACIONES AL SCROLL
// =====================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observar elementos para animación
document.querySelectorAll('.freelancer-card, .category-card, .access-card, .step').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease-out';
    observer.observe(el);
});

// =====================
// FILTRADO DE CATEGORÍAS
// =====================
function filterFreelancers(category) {
    console.log('Filtrando por categoría:', category);
    // Lógica de filtrado que se conectará con el backend
}

// =====================
// BUSCADOR DE FREELANCERS
// =====================
function searchFreelancers(query) {
    console.log('Buscando:', query);
    // Lógica de búsqueda que se conectará con el backend
}

// =====================
// FUNCIONES AUXILIARES
// =====================

// Validar email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validar contraseña (mínimo 6 caracteres)
function isValidPassword(password) {
    return password.length >= 6;
}

// Formatear moneda
function formatCurrency(value) {
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'USD'
    }).format(value);
}

// =====================
// GESTIÓN DE PARÁMETROS URL
// =====================
function getURLParameter(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// =====================
// EFECTOS VISUALES
// =====================

// Agregar efecto de ondas al hacer click en botones
document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('mouseenter', function() {
        this.style.transform = this.style.transform || 'translateY(-2px)';
    });
});

// =====================
// NAVBAR SCROLL EFFECT
// =====================
let lastScrollTop = 0;
const header = document.querySelector('.header');

window.addEventListener('scroll', () => {
    let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (scrollTop > 50) {
        header.style.boxShadow = 'var(--shadow-md)';
    } else {
        header.style.boxShadow = 'var(--shadow-sm)';
    }
    
    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
});

// =====================
// LAZY LOADING DE IMÁGENES
// =====================
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img.lazy').forEach(img => {
        imageObserver.observe(img);
    });
}

// =====================
// INICIALIZACIÓN
// =====================
document.addEventListener('DOMContentLoaded', () => {
    console.log('Vulpixia cargado correctamente');
    
    // Aquí puedes agregar código de inicialización adicional
});

// =====================
// EVENT LISTENERS DINÁMICOS
// =====================

// Click en categorías
document.querySelectorAll('.category-card').forEach(card => {
    card.addEventListener('click', function() {
        const categoryName = this.querySelector('h3').textContent;
        // Redirigir o filtrar
        console.log('Categoría seleccionada:', categoryName);
    });
});

// Click en "Contactar" freelancer
document.querySelectorAll('.freelancer-card .btn-primary').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        const profileLink = this.closest('.freelancer-card')?.querySelector('a[href*="freelancer-profile.html?id="]');
        const profileId = profileLink ? new URL(profileLink.href, window.location.href).searchParams.get('id') : '';
        window.location.href = `pages/messages.html${profileId ? `?to=${encodeURIComponent(profileId)}` : ''}`;
    });
});

// Prevenir múltiples envíos del formulario
contactForm?.addEventListener('submit', (e) => {
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    
    setTimeout(() => {
        submitBtn.disabled = false;
    }, 2000);
});

// =====================
// DARK MODE (Opcional)
// =====================
const prefersDarkMode = window.matchMedia('(prefers-color-scheme: dark)');

function toggleDarkMode(enable) {
    if (enable) {
        document.documentElement.style.setProperty('--light-bg', '#0F172A');
        document.documentElement.style.setProperty('--text-white', '#1E293B');
    } else {
        document.documentElement.style.setProperty('--light-bg', '#F8FAFC');
        document.documentElement.style.setProperty('--text-white', '#FFFFFF');
    }
    localStorage.setItem('darkMode', enable);
}

// Cargar preferencia de dark mode
if (localStorage.getItem('darkMode') === 'true') {
    toggleDarkMode(true);
}

// =====================
// MARKETPLACE FREELANCER
// =====================
(() => {
    const freelancers = [
        {
            id: 1,
            name: 'Carlos Mendoza',
            title: 'Desarrollador Web Full Stack',
            category: 'programacion',
            categoryLabel: 'Programación',
            avatar: 'https://i.pravatar.cc/400?img=1',
            rating: 4.9,
            reviews: 128,
            projects: 86,
            rate: 50,
            delivery: '24h',
            response: '1h',
            responseMinutes: 60,
            completion: 98,
            points: 2450,
            level: 'Elite',
            premium: true,
            skills: ['React', 'Node.js', 'MongoDB', 'API REST'],
            packages: [{ name: 'Landing page', price: 180 }, { name: 'App web', price: 650 }]
        },
        {
            id: 2,
            name: 'Sofia García',
            title: 'Diseñadora Gráfica Creativa',
            category: 'diseno',
            categoryLabel: 'Diseño',
            avatar: 'https://i.pravatar.cc/400?img=47',
            rating: 4.8,
            reviews: 94,
            projects: 73,
            rate: 40,
            delivery: 'semana',
            response: '2h',
            responseMinutes: 120,
            completion: 96,
            points: 1760,
            level: 'Pro',
            premium: true,
            skills: ['Figma', 'Branding', 'UI/UX', 'Logos'],
            packages: [{ name: 'Logo profesional', price: 120 }, { name: 'Brand kit', price: 390 }]
        },
        {
            id: 3,
            name: 'Juan López',
            title: 'Editor de Video Profesional',
            category: 'video',
            categoryLabel: 'Video',
            avatar: 'https://i.pravatar.cc/400?img=33',
            rating: 4.7,
            reviews: 67,
            projects: 58,
            rate: 45,
            delivery: 'semana',
            response: '4h',
            responseMinutes: 240,
            completion: 91,
            points: 980,
            level: 'Plata',
            premium: false,
            skills: ['Premiere Pro', 'After Effects', 'Motion', 'Reels'],
            packages: [{ name: 'Video corto', price: 85 }, { name: 'Video corporativo', price: 420 }]
        },
        {
            id: 4,
            name: 'Andrea Rodríguez',
            title: 'Especialista en Marketing Digital',
            category: 'marketing',
            categoryLabel: 'Marketing',
            avatar: 'https://i.pravatar.cc/400?img=64',
            rating: 4.9,
            reviews: 142,
            projects: 101,
            rate: 55,
            delivery: '24h',
            response: '1h',
            responseMinutes: 60,
            completion: 99,
            points: 2310,
            level: 'Elite',
            premium: true,
            skills: ['SEO', 'SEM', 'Social Media', 'Analytics'],
            packages: [{ name: 'Auditoría SEO', price: 150 }, { name: 'Campaña mensual', price: 780 }]
        },
        {
            id: 5,
            name: 'David Velasco',
            title: 'Ilustrador Digital Creativo',
            category: 'diseno',
            categoryLabel: 'Diseño',
            avatar: 'https://i.pravatar.cc/400?img=82',
            rating: 4.6,
            reviews: 52,
            projects: 44,
            rate: 35,
            delivery: 'semana',
            response: '6h',
            responseMinutes: 360,
            completion: 84,
            points: 520,
            level: 'Bronce',
            premium: false,
            skills: ['Ilustración', 'Concept Art', '3D', 'Personajes'],
            packages: [{ name: 'Ilustración', price: 95 }, { name: 'Pack 3 artes', price: 240 }]
        },
        {
            id: 6,
            name: 'Martina Fernández',
            title: 'Community Manager Especialista',
            category: 'marketing',
            categoryLabel: 'Marketing',
            avatar: 'https://i.pravatar.cc/400?img=29',
            rating: 4.8,
            reviews: 81,
            projects: 69,
            rate: 30,
            delivery: '24h',
            response: '1h',
            responseMinutes: 60,
            completion: 93,
            points: 1120,
            level: 'Plata',
            premium: false,
            skills: ['Community', 'Content', 'Strategy', 'Calendarios'],
            packages: [{ name: 'Calendario semanal', price: 75 }, { name: 'Gestión mensual', price: 520 }]
        },
        {
            id: 7,
            name: 'Nicolás Ferrer',
            title: 'Consultor de IA y Automatización',
            category: 'ia',
            categoryLabel: 'Inteligencia Artificial',
            avatar: 'https://i.pravatar.cc/400?img=12',
            rating: 5.0,
            reviews: 39,
            projects: 31,
            rate: 70,
            delivery: '24h',
            response: '45m',
            responseMinutes: 45,
            completion: 100,
            points: 2680,
            level: 'Elite',
            premium: true,
            skills: ['Chatbots', 'OpenAI', 'Automatización', 'Python'],
            packages: [{ name: 'Chatbot base', price: 380 }, { name: 'Automatización completa', price: 1200 }]
        },
        {
            id: 8,
            name: 'Laura Méndez',
            title: 'Copywriter y Redactora SEO',
            category: 'redaccion',
            categoryLabel: 'Redacción',
            avatar: 'https://i.pravatar.cc/400?img=45',
            rating: 4.9,
            reviews: 76,
            projects: 64,
            rate: 28,
            delivery: '24h',
            response: '2h',
            responseMinutes: 120,
            completion: 95,
            points: 1510,
            level: 'Pro',
            premium: false,
            skills: ['SEO', 'Copywriting', 'Blogs', 'Ventas'],
            packages: [{ name: 'Artículo SEO', price: 60 }, { name: 'Landing copy', price: 180 }]
        }
    ];

    const state = {
        query: '',
        category: '',
        budget: '',
        availability: '',
        level: '',
        sort: 'relevance',
        savedOnly: false,
        saved: new Set(JSON.parse(localStorage.getItem('vulpixia_saved_freelancers') || '[]'))
    };

    const grid = document.querySelector('.freelancers-grid');
    const resultsCount = document.getElementById('resultsCount');
    const savedCount = document.getElementById('savedCount');

    if (!grid || !resultsCount) return;

    createMarketplaceModals();
    bindMarketplaceEvents();
    renderFreelancers();
    updateSavedCount();

    function bindMarketplaceEvents() {
        document.getElementById('marketplaceSearch')?.addEventListener('submit', event => {
            event.preventDefault();
            state.query = document.getElementById('heroSearchInput').value.trim().toLowerCase();
            state.category = document.getElementById('heroCategorySelect').value;
            document.getElementById('filterCategory').value = state.category;
            state.savedOnly = false;
            scrollToFreelancers();
            renderFreelancers();
        });

        ['filterCategory', 'filterBudget', 'filterAvailability', 'filterLevel', 'sortFreelancers'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', event => {
                if (id === 'filterCategory') state.category = event.target.value;
                if (id === 'filterBudget') state.budget = event.target.value;
                if (id === 'filterAvailability') state.availability = event.target.value;
                if (id === 'filterLevel') state.level = event.target.value;
                if (id === 'sortFreelancers') state.sort = event.target.value;
                state.savedOnly = false;
                renderFreelancers();
            });
        });

        document.getElementById('clearFilters')?.addEventListener('click', () => {
            state.query = '';
            state.category = '';
            state.budget = '';
            state.availability = '';
            state.level = '';
            state.sort = 'relevance';
            state.savedOnly = false;
            ['heroSearchInput', 'heroCategorySelect', 'filterCategory', 'filterBudget', 'filterAvailability', 'filterLevel'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
            document.getElementById('sortFreelancers').value = 'relevance';
            renderFreelancers();
        });

        document.getElementById('showSavedFreelancers')?.addEventListener('click', () => {
            state.savedOnly = !state.savedOnly;
            renderFreelancers();
        });

        document.querySelectorAll('.category-card').forEach(card => {
            card.addEventListener('click', event => {
                event.preventDefault();
                const categoryName = card.querySelector('h3')?.textContent || '';
                state.category = mapCategory(categoryName);
                document.getElementById('filterCategory').value = state.category;
                scrollToFreelancers();
                renderFreelancers();
            });
        });

        document.getElementById('openProjectBrief')?.addEventListener('click', openProjectModal);
        document.getElementById('openProjectBriefSecondary')?.addEventListener('click', openProjectModal);
    }

    function renderFreelancers() {
        let list = freelancers.filter(matchesFilters);

        list = list.sort((a, b) => {
            if (state.sort === 'rating') return b.rating - a.rating;
            if (state.sort === 'projects') return b.projects - a.projects;
            if (state.sort === 'completion') return b.completion - a.completion;
            if (state.sort === 'response') return a.responseMinutes - b.responseMinutes;
            if (state.sort === 'level') return levelRank(b.level) - levelRank(a.level) || b.points - a.points;
            if (state.sort === 'price') return a.rate - b.rate;
            return Number(b.premium) - Number(a.premium) || levelRank(b.level) - levelRank(a.level) || b.rating - a.rating;
        });

        grid.innerHTML = list.length
            ? list.map(renderFreelancerCard).join('')
            : `<div class="empty-state">
                <h3>No encontramos freelancers con esos filtros</h3>
                <p>Prueba con otra categoría, presupuesto o disponibilidad.</p>
            </div>`;

        resultsCount.textContent = `${list.length} freelancer${list.length === 1 ? '' : 's'} encontrado${list.length === 1 ? '' : 's'}`;
        bindCardActions();
    }

    function matchesFilters(freelancer) {
        const haystack = [
            freelancer.name,
            freelancer.title,
            freelancer.categoryLabel,
            ...freelancer.skills
        ].join(' ').toLowerCase();

        if (state.savedOnly && !state.saved.has(freelancer.id)) return false;
        if (state.query && !haystack.includes(state.query)) return false;
        if (state.category && freelancer.category !== state.category) return false;
        if (state.budget && freelancer.rate > Number(state.budget)) return false;
        if (state.availability && freelancer.delivery !== state.availability) return false;
        if (state.level && levelSlug(freelancer.level) !== state.level) return false;
        return true;
    }

    function renderFreelancerCard(freelancer) {
        const saved = state.saved.has(freelancer.id);
        const level = levelSlug(freelancer.level);
        return `
            <div class="freelancer-card ${freelancer.premium ? 'premium-profile' : ''}" data-id="${freelancer.id}">
                <div class="card-header">
                    <img src="${freelancer.avatar}" alt="${freelancer.name}" class="avatar">
                    <button class="save-btn ${saved ? 'saved' : ''}" type="button" data-action="save" title="Guardar freelancer">
                        <i class="${saved ? 'fas' : 'far'} fa-heart"></i>
                    </button>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <span>${freelancer.rating.toFixed(1)}</span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="level-row">
                        <span class="profile-badge level-${level}">
                            <i class="${levelIcon(level)}"></i>
                            ${freelancer.level}
                        </span>
                        <span class="level-points">${freelancer.points.toLocaleString('es-CO')} pts</span>
                    </div>
                    <h3>${freelancer.name}</h3>
                    <p class="specialty">${freelancer.title}</p>
                    <div class="price">Desde <strong>$${freelancer.rate}/hr</strong></div>
                    <div class="skills">
                        ${freelancer.skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
                    </div>
                    <div class="freelancer-metrics">
                        <div class="metric"><strong>${freelancer.projects}</strong><span>proyectos</span></div>
                        <div class="metric metric-success"><strong>${freelancer.completion}%</strong><span>finalizados</span></div>
                        <div class="metric"><strong>${freelancer.reviews}</strong><span>reseñas</span></div>
                    </div>
                    <div class="completion-meter" aria-label="${freelancer.completion}% de trabajos completados">
                        <div class="completion-meter-top">
                            <span>Trabajos completados</span>
                            <strong>${freelancer.completion}%</strong>
                        </div>
                        <div class="completion-bar"><span style="width: ${freelancer.completion}%"></span></div>
                    </div>
                    <div class="engagement-row">
                        <span><i class="fas fa-clock"></i> Responde en ${freelancer.response}</span>
                        <span><i class="fas fa-star"></i> ${freelancer.reviews} resenas</span>
                    </div>
                    ${freelancer.packages.map(pack => `
                        <div class="package-row">
                            <span>${pack.name}</span>
                            <strong>desde $${pack.price}</strong>
                        </div>
                    `).join('')}
                </div>
                <div class="card-footer">
                    <a href="pages/freelancer-profile.html?id=${freelancer.id}" class="btn btn-outline btn-small">Ver perfil</a>
                    <button class="btn btn-primary btn-small" type="button" data-action="contact">Chat</button>
                </div>
            </div>
        `;
    }

    function bindCardActions() {
        grid.querySelectorAll('[data-action="save"]').forEach(button => {
            button.addEventListener('click', () => {
                const id = Number(button.closest('.freelancer-card').dataset.id);
                if (state.saved.has(id)) {
                    state.saved.delete(id);
                } else {
                    state.saved.add(id);
                }
                localStorage.setItem('vulpixia_saved_freelancers', JSON.stringify([...state.saved]));
                updateSavedCount();
                renderFreelancers();
            });
        });

        grid.querySelectorAll('[data-action="contact"]').forEach(button => {
            button.addEventListener('click', () => {
                const id = Number(button.closest('.freelancer-card').dataset.id);
                window.location.href = `pages/messages.html?to=${encodeURIComponent(id)}`;
            });
        });
    }

    function updateSavedCount() {
        if (savedCount) savedCount.textContent = state.saved.size;
    }

    function levelSlug(level) {
        return String(level || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }

    function levelRank(level) {
        return {
            bronce: 1,
            plata: 2,
            pro: 3,
            elite: 4
        }[levelSlug(level)] || 0;
    }

    function levelIcon(level) {
        return {
            bronce: 'fas fa-medal',
            plata: 'fas fa-shield-halved',
            pro: 'fas fa-award',
            elite: 'fas fa-crown'
        }[level] || 'fas fa-award';
    }

    function mapCategory(categoryName) {
        const normalized = categoryName.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        if (normalized.includes('program') || normalized.includes('web') || normalized.includes('movil')) return 'programacion';
        if (normalized.includes('diseno') || normalized.includes('arte') || normalized.includes('ilustr')) return 'diseno';
        if (normalized.includes('video') || normalized.includes('animacion')) return 'video';
        if (normalized.includes('marketing') || normalized.includes('community')) return 'marketing';
        if (normalized.includes('redaccion') || normalized.includes('traduccion')) return 'redaccion';
        if (normalized.includes('inteligencia')) return 'ia';
        return '';
    }

    function scrollToFreelancers() {
        document.getElementById('freelancers')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function createMarketplaceModals() {
        document.body.insertAdjacentHTML('beforeend', `
            <div class="marketplace-modal" id="contactFreelancerModal" aria-hidden="true">
                <div class="modal-panel">
                    <div class="modal-header">
                        <h3 id="contactModalTitle">Solicitar cotización</h3>
                        <button class="modal-close" type="button" data-close-modal><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form class="modal-form" id="quoteForm">
                            <div class="modal-grid">
                                <label>Nombre
                                    <input name="name" type="text" required>
                                </label>
                                <label>Correo
                                    <input name="email" type="email" required>
                                </label>
                            </div>
                            <label>Tipo de proyecto
                                <select name="projectType" required>
                                    <option value="">Selecciona una opción</option>
                                    <option>Landing page</option>
                                    <option>Diseño de marca</option>
                                    <option>Campaña digital</option>
                                    <option>Automatización</option>
                                    <option>Otro</option>
                                </select>
                            </label>
                            <div class="modal-grid">
                                <label>Presupuesto
                                    <input name="budget" type="number" min="50" placeholder="USD" required>
                                </label>
                                <label>Fecha ideal
                                    <input name="deadline" type="date" required>
                                </label>
                            </div>
                            <label>Descripción
                                <textarea name="description" rows="5" minlength="20" required></textarea>
                            </label>
                            <button class="btn btn-primary btn-large" type="submit">
                                <i class="fas fa-paper-plane"></i>
                                Enviar solicitud
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="marketplace-modal" id="projectBriefModal" aria-hidden="true">
                <div class="modal-panel">
                    <div class="modal-header">
                        <h3>Publicar proyecto</h3>
                        <button class="modal-close" type="button" data-close-modal><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form class="modal-form" id="projectBriefForm">
                            <label>Título del proyecto
                                <input name="title" type="text" placeholder="Ej. Necesito una tienda online" required>
                            </label>
                            <div class="modal-grid">
                                <label>Categoría
                                    <select name="category" required>
                                        <option value="">Selecciona una categoría</option>
                                        <option>Programación</option>
                                        <option>Diseño</option>
                                        <option>Video</option>
                                        <option>Marketing</option>
                                        <option>Redacción</option>
                                        <option>Inteligencia Artificial</option>
                                    </select>
                                </label>
                                <label>Presupuesto estimado
                                    <input name="budget" type="number" min="50" placeholder="USD" required>
                                </label>
                            </div>
                            <div class="modal-grid">
                                <label>Plazo
                                    <select name="timeline" required>
                                        <option value="">Selecciona un plazo</option>
                                        <option>24-72 horas</option>
                                        <option>1 semana</option>
                                        <option>2-4 semanas</option>
                                        <option>Flexible</option>
                                    </select>
                                </label>
                                <label>Nivel requerido
                                    <select name="level" required>
                                        <option>Intermedio</option>
                                        <option>Experto</option>
                                        <option>Top Rated</option>
                                    </select>
                                </label>
                            </div>
                            <label>Detalles del proyecto
                                <textarea name="description" rows="5" minlength="30" required></textarea>
                            </label>
                            <button class="btn btn-primary btn-large" type="submit">
                                <i class="fas fa-check"></i>
                                Publicar y recibir propuestas
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        `);

        document.querySelectorAll('[data-close-modal]').forEach(button => {
            button.addEventListener('click', () => closeModals());
        });

        document.querySelectorAll('.marketplace-modal').forEach(modal => {
            modal.addEventListener('click', event => {
                if (event.target === modal) closeModals();
            });
        });

        document.getElementById('quoteForm').addEventListener('submit', event => {
            event.preventDefault();
            const request = Object.fromEntries(new FormData(event.target));
            request.freelancer = event.target.dataset.freelancer || '';
            request.createdAt = new Date().toISOString();
            saveLocalRecord('vulpixia_quote_requests', request);
            closeModals();
            showMarketplaceToast('Solicitud enviada. El freelancer recibirá tu brief y podrá responder con una propuesta.');
            event.target.reset();
        });

        document.getElementById('projectBriefForm').addEventListener('submit', event => {
            event.preventDefault();
            const project = Object.fromEntries(new FormData(event.target));
            project.status = 'abierto';
            project.createdAt = new Date().toISOString();
            saveLocalRecord('vulpixia_project_briefs', project);
            closeModals();
            showMarketplaceToast('Proyecto publicado en modo demo. Ya puedes recibir propuestas de freelancers.');
            event.target.reset();
        });
    }

    function openContactModal(freelancer) {
        const modal = document.getElementById('contactFreelancerModal');
        document.getElementById('contactModalTitle').textContent = `Solicitar cotización a ${freelancer.name}`;
        document.getElementById('quoteForm').dataset.freelancer = freelancer.name;
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
    }

    function openProjectModal() {
        const modal = document.getElementById('projectBriefModal');
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
    }

    function closeModals() {
        document.querySelectorAll('.marketplace-modal').forEach(modal => {
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden', 'true');
        });
    }

    function saveLocalRecord(key, record) {
        const records = JSON.parse(localStorage.getItem(key) || '[]');
        records.unshift(record);
        localStorage.setItem(key, JSON.stringify(records.slice(0, 20)));
    }

    function showMarketplaceToast(message) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            max-width: 380px;
            background: #10B981;
            color: white;
            padding: 1rem 1.25rem;
            border-radius: 0.5rem;
            z-index: 5000;
            box-shadow: 0 12px 30px rgba(0,0,0,0.18);
            font-weight: 700;
        `;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 4200);
    }
})();
