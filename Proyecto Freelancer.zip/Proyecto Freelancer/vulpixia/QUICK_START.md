# 🚀 Guía Rápida de Instalación - Vulpixia

## ⚡ Instalación en 5 minutos

### 1️⃣ Requisitos Previos
- PHP 7.4+
- MySQL 5.7+
- XAMPP, WAMP, LAMP o servidor local

### 2️⃣ Descargar el Proyecto

```bash
# Opción 1: Clone del repositorio
git clone https://github.com/tu-usuario/vulpixia.git
cd vulpixia

# Opción 2: Descarga manual
# Descarga el ZIP y extrae en tu directorio web
```

### 3️⃣ Configurar la Base de Datos

#### Con XAMPP/WAMP:

1. Abre phpMyAdmin: `http://localhost/phpmyadmin`
2. Crea una nueva base de datos llamada `vulpixia_db`
3. Selecciona la BD y vete a "Importar"
4. Sube el archivo `backend/database.sql`
5. ¡Listo!

#### Con línea de comandos:

```bash
mysql -u root -p < backend/database.sql
```

### 4️⃣ Configurar Conexión

Edita `backend/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Tu usuario
define('DB_PASS', '');            // Tu contraseña (vacío si no tienes)
define('DB_NAME', 'vulpixia_db');
```

### 5️⃣ Iniciar el Servidor

**Opción 1: PHP Incorporado**
```bash
cd vulpixia
php -S localhost:8000
# Accede a http://localhost:8000
```

**Opción 2: XAMPP**
1. Coloca la carpeta en `htdocs/`
2. Inicia Apache y MySQL
3. Accede a `http://localhost/vulpixia/`

## 📋 Estructura Rápida

```
vulpixia/
├── index.html                 # 🏠 Página principal
├── pages/
│   ├── login.html            # 🔐 Login
│   ├── register.html         # 📝 Registro
│   └── freelancer-profile.html # 👤 Perfil freelancer
├── assets/
│   ├── css/style.css         # 🎨 Estilos
│   ├── js/script.js          # ⚙️ Funcionalidad
└── backend/
    ├── config.php            # ⚙️ Configuración
    ├── database.php          # 💾 BD
    └── handlers.php          # 🔗 API
```

## 🧪 Datos de Prueba

Puedes crear tu propia cuenta o usar estos datos:

### Cliente
- Email: `cliente@example.com`
- Contraseña: `password123`

### Freelancer
- Email: `freelancer@example.com`
- Contraseña: `password123`

## ✅ Verificar Instalación

1. **Accede a la página principal:**
   - URL: `http://localhost:8000` o `http://localhost/vulpixia/`
   - Debes ver el diseño morado y azul

2. **Prueba el registro:**
   - Click en "Registrarse"
   - Completa el formulario
   - Deberías ver un mensaje de éxito

3. **Verifica la BD:**
   - Abre phpMyAdmin
   - La tabla `usuarios` debe tener tus datos

## 🔧 Solución de Problemas

### Error: "No se puede conectar a la base de datos"
```
✓ Verifica que MySQL esté corriendo
✓ Revisa las credenciales en backend/config.php
✓ Asegúrate que la BD existe
```

### Error: "Página no encontrada"
```
✓ Verifica la URL
✓ Asegúrate que PHP esté corriendo
✓ Revisa que los archivos estén en el lugar correcto
```

### Error: "No se puede importar SQL"
```
✓ Copia el contenido de database.sql
✓ Pégalo en phpMyAdmin > SQL
✓ Ejecuta
```

### La página se ve extraña
```
✓ Limpia la caché del navegador (Ctrl+F5)
✓ Abre en otro navegador
✓ Revisa la consola (F12) para errores
```

## 📱 Prueba en Móvil

Para acceder desde otro dispositivo:

```bash
# Obtén tu IP local
ipconfig getifaddr en0  # Mac/Linux
ipconfig             # Windows

# Accede con: http://TU_IP:8000
```

## 📖 Próximos Pasos

1. **Explora las páginas:**
   - Visita todas las secciones del sitio
   - Prueba los formularios

2. **Lee la documentación:**
   - Abre `README.md` para características
   - Abre `API_DOCUMENTATION.md` para endpoints

3. **Personaliza:**
   - Cambia colores en `assets/css/style.css`
   - Modifica contenido en HTML
   - Agrega funcionalidades en JS

## 🎓 Aprender Más

- **Frontend:** HTML, CSS, JavaScript
- **Backend:** PHP, MySQL
- **Herramientas:** Git, phpMyAdmin

## 💡 Tips Útiles

```bash
# Crear carpeta de logs
mkdir logs

# Crear carpeta de uploads
mkdir uploads

# Establecer permisos (Linux/Mac)
chmod 755 uploads/
chmod 755 logs/
```

## 🆘 ¿Necesitas Ayuda?

1. **Issues:** Crea un issue en GitHub
2. **Documentación:** Lee README.md
3. **API Docs:** Lee API_DOCUMENTATION.md

## ✨ ¡Listo para Empezar!

```bash
# El comando mágico:
php -S localhost:8000 && echo "✨ Vulpixia está lista en http://localhost:8000"
```

---

**Felicidades, tu Vulpixia está instalada** 🎉

Para cualquier pregunta, consulta la documentación completa en README.md
