# GUÍA TÉCNICA - IMPLEMENTACIÓN DE NUEVAS CARACTERÍSTICAS

## 1. INSTALACIÓN Y CONFIGURACIÓN

### Paso 1: Actualizar Base de Datos

```sql
-- Ejecutar en MySQL
mysql -u root -p vulpixia_db < backend/database.sql

-- O importar en phpmyadmin
1. Ir a Importar
2. Seleccionar backend/database.sql
3. Hacer clic en "Ir"
```

### Paso 2: Verificar Rutas de Archivos

```
vulpixia/
├── pages/
│   ├── memberships.html ✅ NUEVO
│   ├── ranking.html ✅ NUEVO
│   ├── legal/
│   │   ├── terms.html ✅ NUEVO
│   │   └── privacy.html ✅ NUEVO
│   ├── register.html (MODIFICADO)
│   └── ... (otros)
├── backend/
│   ├── subscriptions.php ✅ NUEVO
│   ├── database.sql (MODIFICADO)
│   └── ... (otros)
└── index.html (MODIFICADO)
```

### Paso 3: Permisos de Archivos

```bash
# Asegurar permisos de lectura
chmod 644 pages/memberships.html
chmod 644 pages/ranking.html
chmod 644 pages/legal/terms.html
chmod 644 pages/legal/privacy.html
chmod 755 backend/subscriptions.php
```

---

## 2. INTEGRACIONES DE BACKEND

### Activar Endpoints de Suscripciones

**En `backend/handlers.php`, agregar:**

```php
// Agregar esta línea en el router principal
case 'get_subscription_status':
    handleGetSubscriptionStatus();
    break;

// Función helper
function handleGetSubscriptionStatus() {
    if (!isAuthenticated()) {
        respondJSON('error', 'No autenticado');
        return;
    }
    
    require_once 'subscriptions.php';
    handleGetUserSubscription();
}
```

### API Endpoints Disponibles

```
GET /backend/subscriptions.php?action=get_plans
├─ Retorna: array de planes
├─ Parámetros: ninguno
└─ Autenticación: No requerida

GET /backend/subscriptions.php?action=get_user_subscription
├─ Retorna: suscripción actual del usuario
├─ Parámetros: ninguno
└─ Autenticación: SÍ REQUERIDA

POST /backend/subscriptions.php?action=upgrade_plan
├─ Retorna: confirmación de actualización
├─ Parámetros: plan_id (int)
└─ Autenticación: SÍ REQUERIDA

POST /backend/subscriptions.php?action=cancel_subscription
├─ Retorna: confirmación de cancelación
├─ Parámetros: ninguno
└─ Autenticación: SÍ REQUERIDA

GET /backend/subscriptions.php?action=get_ranking
├─ Retorna: lista de usuarios ordenados
├─ Parámetros: tipo, categoria, limit, offset
└─ Autenticación: No requerida

POST /backend/subscriptions.php?action=update_ranking
├─ Retorna: confirmación de actualización
├─ Parámetros: usuario_id (int)
└─ Autenticación: No requerida (llamada interna)
```

---

## 3. CAMBIOS EN BASE DE DATOS

### Nuevas Tablas Creadas

#### `planes_suscripcion`
```sql
-- Almacena definiciones de planes
SELECT * FROM planes_suscripcion;

-- Datos precargados:
-- ID | Nombre | Tipo | Precio | Límites
-- 1  | Básico | basico | 0.00
-- 2  | Profesional | profesional | 9.99
-- 3  | Premium | premium | 24.99
-- 4  | Empresarial | empresarial | 99.99
```

#### `suscripciones`
```sql
-- Almacena suscripciones activas de usuarios
-- Un registro por usuario (relación 1:1)
-- Estados: activa, suspendida, cancelada

-- Ejemplo de consulta:
SELECT u.nombre, p.nombre as plan, s.proxima_renovacion
FROM suscripciones s
JOIN usuarios u ON s.usuario_id = u.id
JOIN planes_suscripcion p ON s.plan_id = p.id
WHERE s.estado = 'activa'
ORDER BY s.proxima_renovacion;
```

#### `historial_suscripciones`
```sql
-- Auditoría de cambios de planes
-- Un registro por cambio realizado

SELECT * FROM historial_suscripciones
ORDER BY fecha_cambio DESC;
```

#### `terminos_aceptados`
```sql
-- Registro de consentimiento legal
-- Un registro por usuario al registrarse

SELECT * FROM terminos_aceptados
WHERE usuario_id = 1;
```

#### `ranking_usuarios`
```sql
-- Posición y puntos de cada usuario
-- Se actualiza después de cada proyecto completado

SELECT usuario_id, puntos_totales, posicion, nivel
FROM ranking_usuarios
ORDER BY puntos_totales DESC LIMIT 10;
```

#### `historial_ranking`
```sql
-- Histórico mensual de posiciones
-- Permite analizar tendencias

SELECT * FROM historial_ranking
WHERE usuario_id = 1
ORDER BY ano DESC, mes DESC;
```

---

## 4. FLUJOS DE USUARIO

### Flujo 1: Registro con Términos Legales

```
1. Usuario abre pages/register.html
2. Completa formulario básico
3. DEBE aceptar:
   ✓ Términos de Servicio (requerido)
   ✓ Política de Privacidad (requerido)
   ✓ Marketing (opcional)
4. Submit ejecuta validación:
   - Verifica terminos === true
   - Verifica privacidad === true
   - Guarda marketing preference
5. Backend guarda en terminos_aceptados
6. Crea suscripción básica (gratis)
7. Redirige a index.html
```

**JavaScript Clave:**
```javascript
if (!terminos || !privacidad) {
    alert('Debes aceptar los términos legales');
    return false;
}
```

### Flujo 2: Upgrade de Plan

```
1. Usuario autenticado abre pages/memberships.html
2. Hace clic en "Actualizar a [Plan]"
3. Muestra confirmación
4. AJAX POST a backend/subscriptions.php?action=upgrade_plan
5. Backend:
   - Valida autenticación
   - Obtiene plan nuevo
   - Guarda en historial
   - Actualiza suscripciones
6. Muestra confirmación al usuario
7. Actualiza UI (botón a "Tu plan actual")
```

### Flujo 3: Ver Ranking

```
1. Usuario abre pages/ranking.html
2. Aplica filtros (categoría, período, nivel)
3. AJAX GET a backend/subscriptions.php?action=get_ranking
4. Backend:
   - Consulta ranking_usuarios
   - Filtra según parámetros
   - Ordena por puntos
   - Retorna con límite/offset
5. Muestra top 3 y lista paginada
6. Usuario puede:
   - Ver perfil completo
   - Contactar freelancer
   - Cambiar filtros
```

---

## 5. TABLA DE PUNTUACIÓN

### Cálculo de Puntos

```
Base = 0

Por cada proyecto completado:
+ 100 puntos

Por calificación promedio:
+ (promedio × 50) puntos

Ejemplo:
- 10 proyectos completados = 1000 puntos
- Calificación 5.0 = 250 puntos
- Total = 1250 puntos
```

### Niveles por Puntos

| Puntos | Nivel | Color | Badge |
|--------|-------|-------|-------|
| 0-999 | Principiante | Gris | Novato |
| 1000-1999 | Intermedio | Azul | Activo |
| 2000-4999 | Experto | Naranja | Experto |
| 5000+ | Élite | Oro | Élite |

---

## 6. INTEGRACIONES RECOMENDADAS

### Integración con Stripe

```php
// En backend/config.php
define('STRIPE_SECRET_KEY', 'sk_test_...');
define('STRIPE_PUBLIC_KEY', 'pk_test_...');

// En backend/subscriptions.php agregar:
function handleStripePayment($usuario_id, $plan_id, $token) {
    require_once 'vendor/autoload.php';
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
    
    // Crear suscripción recurrente
    $subscription = \Stripe\Subscription::create([
        'customer' => $customer_id,
        'items' => [['price' => $price_id]],
        'payment_behavior' => 'default_incomplete',
    ]);
    
    return $subscription;
}
```

### Integración de Email

```php
// En backend/config.php
function sendSubscriptionConfirmation($email, $plan_name) {
    $subject = "Bienvenido a {$plan_name}";
    $message = "Tu suscripción ha sido activada exitosamente.";
    
    mail($email, $subject, $message, [
        'From' => 'noreply@vulpixia.com'
    ]);
}
```

### Webhook de Renovación

```php
// backend/webhooks/stripe.php
$event = json_decode($input);

switch($event->type) {
    case 'customer.subscription.updated':
        updateSubscriptionStatus($event->data->object);
        break;
    case 'invoice.payment_failed':
        handlePaymentFailure($event->data->object);
        break;
}
```

---

## 7. QUERIES ÚTILES

### Obtener usuarios por nivel

```sql
SELECT u.nombre, r.nivel, r.puntos_totales
FROM ranking_usuarios r
JOIN usuarios u ON r.usuario_id = u.id
WHERE r.nivel = 'Élite'
ORDER BY r.puntos_totales DESC;
```

### Suscripciones próximas a renovarse

```sql
SELECT u.nombre, p.nombre as plan, s.proxima_renovacion
FROM suscripciones s
JOIN usuarios u ON s.usuario_id = u.id
JOIN planes_suscripcion p ON s.plan_id = p.id
WHERE s.proxima_renovacion BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
AND s.estado = 'activa';
```

### Ranking de este mes

```sql
SELECT u.nombre, hr.puntos, hr.posicion
FROM historial_ranking hr
JOIN usuarios u ON hr.usuario_id = u.id
WHERE hr.mes = MONTH(NOW())
AND hr.ano = YEAR(NOW())
ORDER BY hr.posicion;
```

### Análisis de evolución

```sql
SELECT 
    u.nombre,
    (SELECT puntos FROM historial_ranking 
     WHERE usuario_id = u.id 
     ORDER BY fecha_registro DESC LIMIT 1) as puntos_actuales,
    (SELECT puntos FROM historial_ranking 
     WHERE usuario_id = u.id 
     ORDER BY fecha_registro DESC LIMIT 1 OFFSET 1) as puntos_mes_anterior,
    ((SELECT puntos FROM historial_ranking 
     WHERE usuario_id = u.id 
     ORDER BY fecha_registro DESC LIMIT 1) - 
    (SELECT puntos FROM historial_ranking 
     WHERE usuario_id = u.id 
     ORDER BY fecha_registro DESC LIMIT 1 OFFSET 1)) as cambio
FROM usuarios u
WHERE u.tipo_usuario = 'freelancer';
```

---

## 8. TESTING

### Test de Suscripciones

```
✅ Obtener planes
  GET /subscriptions.php?action=get_plans
  Response: 200 OK, Array[4] planes

✅ Crear suscripción
  POST /subscriptions.php?action=upgrade_plan
  Params: plan_id=2
  Response: 200 OK

✅ Verificar suscripción
  GET /subscriptions.php?action=get_user_subscription
  Response: 200 OK, Plan actual

✅ Cancelar suscripción
  POST /subscriptions.php?action=cancel_subscription
  Response: 200 OK
```

### Test de Ranking

```
✅ Obtener ranking
  GET /subscriptions.php?action=get_ranking?limit=20
  Response: 200 OK, Array[20] usuarios

✅ Filtrar por categoría
  GET /subscriptions.php?action=get_ranking?categoria=programacion
  Response: 200 OK, Array[] freelancers filtrados

✅ Actualizar ranking
  POST /subscriptions.php?action=update_ranking
  Params: usuario_id=5
  Response: 200 OK
```

### Test del Formulario

```
✅ Sin aceptar términos
  Input: terminos=false
  Result: Alert "Debes aceptar los términos"
  Status: Submit bloqueado

✅ Aceptando todo
  Input: terminos=true, privacidad=true
  Result: Registro exitoso
  Status: Redirige a index.html
```

---

## 9. MONITOREO Y MANTENIMIENTO

### Logs a Monitorear

```php
// En backend/subscriptions.php se registran:
logError('get_plans', $e->getMessage());
logError('upgrade_plan', $e->getMessage());
logError('update_ranking', $e->getMessage());

// Ubicación: /logs/errors.log
```

### Tareas Programadas Recomendadas

```bash
# Renovar suscripciones automáticas (diaria)
0 0 * * * /usr/bin/php /var/www/vulpixia/cron/renew_subscriptions.php

# Actualizar ranking (semanal)
0 0 * * 0 /usr/bin/php /var/www/vulpixia/cron/update_rankings.php

# Limpiar datos antiguos (mensual)
0 0 1 * * /usr/bin/php /var/www/vulpixia/cron/cleanup_old_data.php
```

### Métricas a Seguir

- Total de usuarios por plan
- Tasa de conversión (Básico → Premium)
- Churn rate (cancelaciones)
- Posiciones en ranking (volatilidad)
- Ingresos por suscripción

---

## 10. SEGURIDAD

### Validaciones Implementadas

✅ Prepared statements (previene SQL injection)
✅ Sanitización de entrada (XSS prevention)
✅ Autenticación requerida para endpoints sensibles
✅ HTTPS recomendado (en producción)
✅ Tokens CSRF (en formularios)

### Mejoras Futuras de Seguridad

- [ ] Rate limiting en API
- [ ] API keys para integraciones
- [ ] 2FA para cuentas premium
- [ ] Encriptación de datos sensibles
- [ ] WAF (Web Application Firewall)

---

**Documento Técnico Versión 2.0**  
**Actualizado: Mayo 6, 2026**
