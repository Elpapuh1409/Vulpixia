# 📁 Estructura del Proyecto - Vulpixia

## Árbol de Directorios Completo

```
vulpixia/
│
├── 📄 index.html                    # Página principal del sitio
├── 📄 README.md                     # Documentación principal
├── 📄 QUICK_START.md                # Guía de instalación rápida
├── 📄 API_DOCUMENTATION.md          # Documentación de API
├── 📄 CUSTOMIZATION_GUIDE.md        # Guía de personalización
├── 📄 INFO.md                       # Información del proyecto
├── 📄 LICENSE                       # Licencia MIT
├── 📄 .gitignore                    # Archivos a ignorar en Git
├── 📄 .env.example                  # Variables de entorno (ejemplo)
├── 📄 .htaccess                     # Configuración Apache
│
├── 📁 pages/                        # Páginas adicionales
│   ├── login.html                   # Página de login
│   ├── register.html                # Página de registro
│   └── freelancer-profile.html      # Perfil de freelancer
│
├── 📁 backend/                      # Código del servidor
│   ├── config.php                   # Configuración y constantes
│   ├── database.php                 # Clase Database con funciones
│   ├── handlers.php                 # Manejadores de API (endpoints)
│   ├── database.sql                 # Script SQL para crear BD
│   └── index.php                    # Prevenir acceso al directorio
│
├── 📁 assets/                       # Recursos del proyecto
│   ├── 📁 css/
│   │   └── style.css                # Estilos CSS (1000+ líneas)
│   │
│   ├── 📁 js/
│   │   └── script.js                # JavaScript (400+ líneas)
│   │
│   └── 📁 images/                   # Imágenes y recursos
│       ├── (Placeholder - usar URLs externas)
│
└── 📁 logs/                         # Archivos de log (crear)
    └── error.log                    # Registro de errores

```

## 📊 Detalles de Cada Archivo

### Raíz del Proyecto

| Archivo | Descripción | Líneas |
|---------|-------------|--------|
| `index.html` | Página principal con todas las secciones | 500+ |
| `README.md` | Documentación completa del proyecto | 300+ |
| `QUICK_START.md` | Guía de instalación en 5 minutos | 150+ |
| `API_DOCUMENTATION.md` | Documentación de endpoints REST | 250+ |
| `CUSTOMIZATION_GUIDE.md` | Guía de personalización | 300+ |
| `INFO.md` | Información detallada del proyecto | 400+ |
| `LICENSE` | Licencia MIT estándar | 20 |
| `.gitignore` | Archivos a excluir de Git | 70 |
| `.env.example` | Variables de entorno de ejemplo | 80 |
| `.htaccess` | Configuración de Apache | 50 |

### Carpeta: pages/

| Archivo | Propósito | Líneas |
|---------|----------|--------|
| `login.html` | Formulario de login | 250+ |
| `register.html` | Formulario de registro dinámico | 350+ |
| `freelancer-profile.html` | Perfil detallado de freelancer | 400+ |

### Carpeta: backend/

| Archivo | Responsabilidad | Líneas |
|---------|-----------------|--------|
| `config.php` | Configuración y funciones auxiliares | 200+ |
| `database.php` | Clase Database con métodos CRUD | 300+ |
| `handlers.php` | Procesamiento de formularios y API | 250+ |
| `database.sql` | Estructura de base de datos | 400+ |
| `index.php` | Seguridad - prevenir acceso directo | 5 |

### Carpeta: assets/css/

| Archivo | Contenido | Líneas |
|---------|----------|--------|
| `style.css` | Estilos principales (variables, responsive) | 1200+ |

### Carpeta: assets/js/

| Archivo | Funcionalidad | Líneas |
|---------|---------------|--------|
| `script.js` | Interactividad (menú, validación, scroll) | 450+ |

## 📈 Estadísticas Totales

```
Total de Archivos:          20+
Total de Líneas de Código:  5000+
Archivos HTML:              4
Archivos CSS:               1
Archivos JavaScript:        1
Archivos PHP:               5
Archivos SQL:               1
Archivos Documentación:     6
Archivos Configuración:     3
```

## 🔄 Flujo de Datos

```
Frontend (HTML/CSS/JS)
    ↓ (submits form)
handlers.php
    ↓ (validates)
config.php (sanitize, hash, etc)
    ↓
database.php (DB operations)
    ↓
MySQL Database
    ↓ (query results)
handlers.php
    ↓ (json response)
Frontend (JavaScript handles response)
    ↓ (updates DOM)
User sees updated content
```

## 🔐 Seguridad - Flujo de Archivo

```
.htaccess (previene acceso directo)
    ↓
backend/index.php (bloquea acceso a carpeta)
    ↓
handlers.php (valida request)
    ↓
config.php (sanitiza inputs)
    ↓
database.php (prepared statements)
    ↓
MySQL (SQL injection prevented)
```

## 📋 Dependencias Entre Archivos

```
index.html
├── assets/css/style.css
├── assets/js/script.js
└── Font Awesome (CDN)

pages/login.html
├── assets/css/style.css
├── assets/js/script.js
├── backend/handlers.php?action=login
└── Font Awesome (CDN)

pages/register.html
├── assets/css/style.css
├── assets/js/script.js
├── backend/handlers.php?action=register
└── Font Awesome (CDN)

pages/freelancer-profile.html
├── assets/css/style.css
├── assets/js/script.js
├── backend/handlers.php?action=get_freelancer
└── Font Awesome (CDN)

backend/handlers.php
├── backend/config.php
├── backend/database.php
└── MySQL Database

backend/database.php
└── backend/config.php

.htaccess
└── Configuración Apache
```

## 🗂️ Cómo Agregar Nuevas Secciones

### Para agregar una nueva página:

1. Crear archivo HTML en `pages/nueva-pagina.html`
2. Importar `assets/css/style.css` y `assets/js/script.js`
3. Seguir estructura de otras páginas
4. Enlazar en header/footer

### Para agregar una nueva funcionalidad:

1. Si es frontend: Agregar JS en `assets/js/script.js`
2. Si es backend: Agregar función en `backend/database.php`
3. Si es endpoint: Agregar case en `backend/handlers.php`
4. Si es BD: Agregar tabla/campos en `backend/database.sql`

### Para agregar nuevos estilos:

1. Editar `assets/css/style.css`
2. Usar variables de color existentes
3. Mantener responsive design

## 🔄 Ciclo de Solicitud HTTP

### Frontend → Backend

```
User clicks button
    ↓
JavaScript event listener
    ↓
Validates data locally
    ↓
Fetches backend/handlers.php?action=xxx
    ↓
POST request con datos
```

### Backend → Database

```
handlers.php receives request
    ↓
config.php sanitizes input
    ↓
database.php executes query
    ↓
MySQL returns results
    ↓
handlers.php formats JSON
    ↓
Sends response to frontend
```

### Frontend Recibe Respuesta

```
JavaScript receives JSON
    ↓
Parses response
    ↓
Checks status (success/error)
    ↓
Updates DOM accordingly
    ↓
User sees result
```

## 📦 Cómo Empaquetar para Entrega

```bash
# Crear un archivo comprimido
tar -czf vulpixia.tar.gz vulpixia/

# O con ZIP
zip -r vulpixia.zip vulpixia/

# Incluir documentación
# NO incluir: .env, logs/, uploads/, node_modules/
```

## ✅ Checklist de Archivos

### Archivos Requeridos
- ✅ index.html
- ✅ backend/config.php
- ✅ backend/database.php
- ✅ backend/handlers.php
- ✅ backend/database.sql
- ✅ assets/css/style.css
- ✅ assets/js/script.js
- ✅ pages/*.html

### Archivos de Documentación
- ✅ README.md
- ✅ QUICK_START.md
- ✅ API_DOCUMENTATION.md
- ✅ CUSTOMIZATION_GUIDE.md
- ✅ INFO.md

### Archivos de Configuración
- ✅ .htaccess
- ✅ .gitignore
- ✅ .env.example
- ✅ LICENSE

### Archivos Opcionales (No Incluir)
- ❌ .env (contiene credenciales)
- ❌ logs/ (se crea automáticamente)
- ❌ uploads/ (se crea automáticamente)
- ❌ node_modules/ (si existe)

## 🚀 Próximas Adiciones

Carpetas/archivos que se pueden agregar:

```
vulpixia/
├── tests/                   # Tests automáticos
│   ├── unit/
│   └── integration/
├── public/                  # Assets públicos
├── vendor/                  # Dependencias Composer
├── config/                  # Configuraciones adicionales
├── migrations/              # Migraciones de BD
└── seeding/                 # Datos de prueba
```

---

**Estructura lista para producción** 🎉

Ver [README.md](README.md) para más detalles.
