<?php
/**
 * Funciones de Base de Datos - Vulpixia
 * Contiene todas las funciones para manipular la base de datos
 */

require_once __DIR__ . '/config.php';

/**
 * Clase Database para manejar operaciones de base de datos
 */
class Database {
    private $conn;
    
    public function __construct() {
        $this->conn = getDBConnection();
    }
    
    /**
     * Registrar nuevo usuario
     */
    public function registerUser($nombre, $email, $password, $tipo_usuario, $datos_adicionales = []) {
        // Verificar si el email ya existe
        if ($this->emailExists($email)) {
            return ['success' => false, 'error' => 'El correo electrónico ya está registrado'];
        }
        
        // Hash de la contraseña
        $hashed_password = hashPassword($password);
        
        // Insertar usuario
        $query = "INSERT INTO usuarios (nombre, email, password, tipo_usuario, fecha_registro) 
                  VALUES (?, ?, ?, ?, NOW())";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssss", $nombre, $email, $hashed_password, $tipo_usuario);
        
        if ($stmt->execute()) {
            $user_id = $this->conn->insert_id;
            
            // Insertar datos adicionales según tipo
            if ($tipo_usuario === 'freelancer' && !empty($datos_adicionales)) {
                $this->insertFreelancerData($user_id, $datos_adicionales);
            } elseif ($tipo_usuario === 'cliente' && !empty($datos_adicionales)) {
                $this->insertClientData($user_id, $datos_adicionales);
            }
            
            return ['success' => true, 'user_id' => $user_id];
        } else {
            return ['success' => false, 'error' => $stmt->error];
        }
    }
    
    /**
     * Verificar si el email existe
     */
    public function emailExists($email) {
        $query = "SELECT id FROM usuarios WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        return $stmt->get_result()->num_rows > 0;
    }
    
    /**
     * Login de usuario
     */
    public function loginUser($email, $password) {
        $query = "SELECT id, nombre, email, password, tipo_usuario FROM usuarios WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return ['success' => false, 'error' => 'Usuario no encontrado'];
        }
        
        $user = $result->fetch_assoc();
        
        if (!verifyPassword($password, $user['password'])) {
            return ['success' => false, 'error' => 'Contraseña incorrecta'];
        }
        
        return [
            'success' => true,
            'user_id' => $user['id'],
            'nombre' => $user['nombre'],
            'email' => $user['email'],
            'tipo_usuario' => $user['tipo_usuario']
        ];
    }
    
    /**
     * Obtener datos del usuario
     */
    public function getUserData($user_id) {
        $query = "SELECT * FROM usuarios WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    /**
     * Insertar datos del freelancer
     */
    public function insertFreelancerData($user_id, $datos) {
        $query = "INSERT INTO freelancers (usuario_id, categoria, habilidades, experiencia, tarifa, portafolio, descripcion) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $categoria = $datos['categoria'] ?? '';
        $habilidades = $datos['habilidades'] ?? '';
        $experiencia = $datos['experiencia'] ?? '';
        $tarifa = $datos['tarifa'] ?? 0;
        $portafolio = $datos['portafolio'] ?? '';
        $descripcion = $datos['descripcion'] ?? '';
        
        $stmt->bind_param("isssids", $user_id, $categoria, $habilidades, $experiencia, $tarifa, $portafolio, $descripcion);
        return $stmt->execute();
    }
    
    /**
     * Insertar datos del cliente
     */
    public function insertClientData($user_id, $datos) {
        $query = "INSERT INTO clientes (usuario_id, tipo_proyecto, empresa, descripcion) 
                  VALUES (?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $tipo_proyecto = $datos['tipo_proyecto'] ?? '';
        $empresa = $datos['empresa'] ?? '';
        $descripcion = $datos['descripcion'] ?? '';
        
        $stmt->bind_param("isss", $user_id, $tipo_proyecto, $empresa, $descripcion);
        return $stmt->execute();
    }
    
    /**
     * Obtener freelancers por categoría
     */
    public function getFreelancersByCategory($category, $limit = 10, $offset = 0) {
        $query = "SELECT u.id, u.nombre, u.email, f.categoria, f.habilidades, f.tarifa, f.portafolio, 
                         (SELECT AVG(calificacion) FROM resenas WHERE usuario_id = u.id) as calificacion,
                         (SELECT COUNT(*) FROM proyectos WHERE freelancer_id = u.id AND estado = 'completado') as proyectos_completados
                  FROM usuarios u
                  JOIN freelancers f ON u.id = f.usuario_id
                  WHERE f.categoria = ?
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sii", $category, $limit, $offset);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Buscar freelancers
     */
    public function searchFreelancers($query, $limit = 10, $offset = 0) {
        $search = "%$query%";
        $sql = "SELECT u.id, u.nombre, u.email, f.categoria, f.habilidades, f.tarifa, f.portafolio,
                       (SELECT AVG(calificacion) FROM resenas WHERE usuario_id = u.id) as calificacion,
                       (SELECT COUNT(*) FROM proyectos WHERE freelancer_id = u.id AND estado = 'completado') as proyectos_completados
                FROM usuarios u
                JOIN freelancers f ON u.id = f.usuario_id
                WHERE u.nombre LIKE ? OR f.categoria LIKE ? OR f.habilidades LIKE ?
                LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssii", $search, $search, $search, $limit, $offset);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Insertar mensaje de contacto
     */
    public function insertContactMessage($nombre, $email, $mensaje) {
        $query = "INSERT INTO contactos (nombre, email, mensaje, fecha_envio) VALUES (?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("sss", $nombre, $email, $mensaje);
        return $stmt->execute();
    }
    
    /**
     * Insertar proyecto
     */
    public function insertProject($cliente_id, $titulo, $descripcion, $categoria, $presupuesto, $fecha_entrega) {
        $query = "INSERT INTO proyectos (cliente_id, titulo, descripcion, categoria, presupuesto, fecha_entrega, estado, fecha_creacion) 
                  VALUES (?, ?, ?, ?, ?, ?, 'abierto', NOW())";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isssds", $cliente_id, $titulo, $descripcion, $categoria, $presupuesto, $fecha_entrega);
        
        if ($stmt->execute()) {
            return ['success' => true, 'project_id' => $this->conn->insert_id];
        }
        return ['success' => false, 'error' => $stmt->error];
    }
    
    /**
     * Obtener proyecto por ID
     */
    public function getProjectById($project_id) {
        $query = "SELECT * FROM proyectos WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $project_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
    
    /**
     * Obtener proyectos del cliente
     */
    public function getClientProjects($cliente_id) {
        $query = "SELECT * FROM proyectos WHERE cliente_id = ? ORDER BY fecha_creacion DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $cliente_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Obtener proyectos del freelancer
     */
    public function getFreelancerProjects($freelancer_id) {
        $query = "SELECT * FROM proyectos WHERE freelancer_id = ? ORDER BY fecha_creacion DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $freelancer_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    /**
     * Actualizar perfil de usuario
     */
    public function updateUserProfile($user_id, $datos) {
        $query = "UPDATE usuarios SET nombre = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $nombre = $datos['nombre'] ?? '';
        $stmt->bind_param("si", $nombre, $user_id);
        return $stmt->execute();
    }
    
    /**
     * Cerrar conexión
     */
    public function closeConnection() {
        $this->conn->close();
    }
}

?>
