<?php
/**
 * Gestor de Suscripciones y Pagos - Vulpixia
 * Maneja planes, checkout demo, suscripciones y visibilidad en ranking.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

header('Content-Type: application/json; charset=utf-8');

$input = getRequestData();
$action = $_GET['action'] ?? $_POST['action'] ?? ($input['action'] ?? '');

switch ($action) {
    case 'get_plans':
        handleGetPlans();
        break;
    case 'get_user_subscription':
        handleGetUserSubscription();
        break;
    case 'create_checkout':
        handleCreateCheckout($input);
        break;
    case 'upgrade_plan':
        handleUpgradePlan($input);
        break;
    case 'cancel_subscription':
        handleCancelSubscription();
        break;
    case 'get_visibility_status':
        handleGetVisibilityStatus();
        break;
    case 'get_ranking':
        handleGetRanking();
        break;
    case 'update_ranking':
        handleUpdateRanking();
        break;
    default:
        respondJSON('error', 'Accion no valida');
}

function getRequestData() {
    $json = json_decode(file_get_contents('php://input'), true);
    if (is_array($json)) {
        return $json;
    }

    return $_POST;
}

function getSubscriptionsDBConnection() {
    mysqli_report(MYSQLI_REPORT_OFF);
    $connection = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

    if ($connection->connect_errno) {
        return null;
    }

    $connection->set_charset('utf8mb4');
    return $connection;
}

function requireUserId() {
    if (!isAuthenticated()) {
        respondJSON('error', 'Debes iniciar sesion para activar un plan de pago');
    }

    return (int) getCurrentUser();
}

function ensurePaymentSchema($connection) {
    $connection->query("
        CREATE TABLE IF NOT EXISTS pagos_suscripcion (
            id INT PRIMARY KEY AUTO_INCREMENT,
            usuario_id INT NOT NULL,
            plan_id INT NOT NULL,
            ciclo ENUM('mensual', 'anual') DEFAULT 'mensual',
            monto DECIMAL(10, 2) NOT NULL,
            moneda VARCHAR(3) DEFAULT 'USD',
            metodo_pago VARCHAR(50) NOT NULL,
            estado ENUM('pendiente', 'aprobado', 'rechazado', 'reembolsado') DEFAULT 'pendiente',
            referencia VARCHAR(255) UNIQUE,
            tarjeta_ultimos4 VARCHAR(4),
            fecha_pago TIMESTAMP NULL,
            fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_usuario (usuario_id),
            INDEX idx_estado (estado),
            INDEX idx_referencia (referencia)
        )
    ");

    addColumnIfMissing($connection, 'suscripciones', 'visibility_boost', "INT DEFAULT 0");
    addColumnIfMissing($connection, 'suscripciones', 'visibility_expires_at', "DATETIME NULL");
    addColumnIfMissing($connection, 'suscripciones', 'billing_cycle', "ENUM('mensual', 'anual') DEFAULT 'mensual'");
    addColumnIfMissing($connection, 'ranking_usuarios', 'tasa_finalizacion', "DECIMAL(5, 2) DEFAULT 0");
    addColumnIfMissing($connection, 'ranking_usuarios', 'tiempo_respuesta_promedio', "INT DEFAULT 0");
}

function addColumnIfMissing($connection, $table, $column, $definition) {
    $dbName = DB_NAME;
    $query = "
        SELECT COUNT(*) as total
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?
    ";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('sss', $dbName, $table, $column);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ((int) $result['total'] === 0) {
        $connection->query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }
}

function getVisibilityBoost($planType) {
    $boosts = [
        'basico' => 0,
        'profesional' => 250,
        'premium' => 800,
        'empresarial' => 1800
    ];

    return $boosts[$planType] ?? 0;
}

function calculatePlanAmount($plan, $billingCycle) {
    $monthly = (float) $plan['precio'];

    if ($billingCycle === 'anual') {
        return round($monthly * 12 * 0.8, 2);
    }

    return round($monthly, 2);
}

function handleGetPlans() {
    $connection = getSubscriptionsDBConnection();

    if (!$connection) {
        respondJSON('success', 'Planes demo obtenidos', getFallbackPlans());
    }

    try {
        $query = "SELECT * FROM planes_suscripcion WHERE activo = TRUE ORDER BY precio ASC";
        $result = $connection->query($query);

        $plans = [];
        while ($row = $result->fetch_assoc()) {
            $plans[] = [
                'id' => (int) $row['id'],
                'nombre' => $row['nombre'],
                'tipo' => $row['tipo'],
                'precio' => (float) $row['precio'],
                'precio_anual' => round((float) $row['precio'] * 12 * 0.8, 2),
                'limite_proyectos' => (int) $row['limite_proyectos'],
                'limite_propuestas' => (int) $row['limite_propuestas'],
                'limite_almacenamiento' => (int) $row['limite_almacenamiento'],
                'descripcion' => $row['descripcion'],
                'caracteristicas' => json_decode($row['caracteristicas'] ?: '[]'),
                'descuento_comision' => (float) $row['descuento_comision'],
                'visibility_boost' => getVisibilityBoost($row['tipo'])
            ];
        }

        respondJSON('success', 'Planes obtenidos', $plans);
    } catch (Exception $e) {
        logError('get_plans: ' . $e->getMessage());
        respondJSON('error', 'Error al obtener planes');
    } finally {
        $connection->close();
    }
}

function getFallbackPlans() {
    return [
        ['id' => 1, 'nombre' => 'Basico', 'tipo' => 'basico', 'precio' => 0, 'precio_anual' => 0, 'visibility_boost' => 0],
        ['id' => 2, 'nombre' => 'Profesional', 'tipo' => 'profesional', 'precio' => 9.99, 'precio_anual' => 95.90, 'visibility_boost' => 250],
        ['id' => 3, 'nombre' => 'Premium', 'tipo' => 'premium', 'precio' => 24.99, 'precio_anual' => 239.90, 'visibility_boost' => 800],
        ['id' => 4, 'nombre' => 'Empresarial', 'tipo' => 'empresarial', 'precio' => 99.99, 'precio_anual' => 959.90, 'visibility_boost' => 1800]
    ];
}

function handleGetUserSubscription() {
    $usuarioId = requireUserId();
    $connection = getSubscriptionsDBConnection();

    if (!$connection) {
        respondJSON('error', 'Base de datos no disponible');
    }

    try {
        ensurePaymentSchema($connection);

        $query = "
            SELECT
                s.id,
                s.plan_id,
                p.nombre as plan_nombre,
                p.tipo,
                p.precio,
                s.estado,
                s.fecha_inicio,
                s.proxima_renovacion,
                s.metodo_pago,
                s.id_transaccion,
                s.auto_renovacion,
                s.visibility_boost,
                s.visibility_expires_at,
                s.billing_cycle
            FROM suscripciones s
            LEFT JOIN planes_suscripcion p ON s.plan_id = p.id
            WHERE s.usuario_id = ? AND s.estado = 'activa'
            LIMIT 1
        ";

        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            respondJSON('success', 'Suscripcion obtenida', [
                'id' => (int) $row['id'],
                'plan_id' => (int) $row['plan_id'],
                'plan_nombre' => $row['plan_nombre'],
                'tipo' => $row['tipo'],
                'precio' => (float) $row['precio'],
                'estado' => $row['estado'],
                'fecha_inicio' => $row['fecha_inicio'],
                'proxima_renovacion' => $row['proxima_renovacion'],
                'metodo_pago' => $row['metodo_pago'],
                'id_transaccion' => $row['id_transaccion'],
                'auto_renovacion' => (bool) $row['auto_renovacion'],
                'visibility_boost' => (int) $row['visibility_boost'],
                'visibility_expires_at' => $row['visibility_expires_at'],
                'billing_cycle' => $row['billing_cycle']
            ]);
        }

        respondJSON('success', 'Sin suscripcion activa', null);
    } catch (Exception $e) {
        logError('get_user_subscription: ' . $e->getMessage());
        respondJSON('error', 'Error al obtener suscripcion');
    } finally {
        $connection->close();
    }
}

function handleCreateCheckout($input) {
    $usuarioId = requireUserId();
    $planId = (int) ($input['plan_id'] ?? 0);
    $billingCycle = sanitizeInput($input['billing_cycle'] ?? 'mensual');
    $paymentMethod = sanitizeInput($input['payment_method'] ?? 'card_demo');
    $cardLast4 = preg_replace('/\D/', '', (string) ($input['card_last4'] ?? ''));

    if (!in_array($billingCycle, ['mensual', 'anual'], true)) {
        respondJSON('error', 'Ciclo de facturacion no valido');
    }

    if ($planId <= 1) {
        respondJSON('error', 'Selecciona un plan de pago');
    }

    if ($paymentMethod !== 'card_demo' || strlen($cardLast4) !== 4) {
        respondJSON('error', 'Metodo de pago no valido');
    }

    $connection = getSubscriptionsDBConnection();
    if (!$connection) {
        respondJSON('error', 'Base de datos no disponible para procesar el pago');
    }

    try {
        ensurePaymentSchema($connection);
        $connection->begin_transaction();

        $plan = findPlan($connection, $planId);
        if (!$plan) {
            throw new Exception('Plan no encontrado');
        }

        $amount = calculatePlanAmount($plan, $billingCycle);
        $transactionId = 'VPX-' . strtoupper(bin2hex(random_bytes(5)));
        $boost = getVisibilityBoost($plan['tipo']);

        $query = "
            INSERT INTO pagos_suscripcion
                (usuario_id, plan_id, ciclo, monto, moneda, metodo_pago, estado, referencia, tarjeta_ultimos4, fecha_pago)
            VALUES
                (?, ?, ?, ?, ?, ?, 'aprobado', ?, ?, NOW())
        ";
        $stmt = $connection->prepare($query);
        $currency = $plan['moneda'] ?: 'USD';
        $stmt->bind_param('iisdssss', $usuarioId, $planId, $billingCycle, $amount, $currency, $paymentMethod, $transactionId, $cardLast4);
        $stmt->execute();

        activateSubscription($connection, $usuarioId, $plan, $billingCycle, $paymentMethod, $transactionId, $boost);
        applyVisibilityBoost($connection, $usuarioId, $plan, $boost);

        $connection->commit();

        respondJSON('success', 'Pago aprobado y plan activado', [
            'transaction_id' => $transactionId,
            'amount' => $amount,
            'currency' => $currency,
            'plan' => $plan['nombre'],
            'billing_cycle' => $billingCycle,
            'visibility_boost' => $boost,
            'visibility_message' => buildVisibilityMessage($plan['tipo'], $boost)
        ]);
    } catch (Exception $e) {
        $connection->rollback();
        logError('create_checkout: ' . $e->getMessage());
        respondJSON('error', 'No se pudo procesar el pago');
    } finally {
        $connection->close();
    }
}

function findPlan($connection, $planId) {
    $query = "SELECT * FROM planes_suscripcion WHERE id = ? AND activo = TRUE LIMIT 1";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $planId);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function activateSubscription($connection, $usuarioId, $plan, $billingCycle, $paymentMethod, $transactionId, $boost) {
    $planId = (int) $plan['id'];
    $interval = $billingCycle === 'anual' ? '1 YEAR' : '1 MONTH';

    $query = "SELECT * FROM suscripciones WHERE usuario_id = ? LIMIT 1";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $current = $stmt->get_result()->fetch_assoc();

    if ($current) {
        $query = "
            UPDATE suscripciones
            SET plan_id = ?,
                estado = 'activa',
                fecha_inicio = CURDATE(),
                proxima_renovacion = DATE_ADD(CURDATE(), INTERVAL {$interval}),
                metodo_pago = ?,
                id_transaccion = ?,
                auto_renovacion = TRUE,
                visibility_boost = ?,
                visibility_expires_at = DATE_ADD(NOW(), INTERVAL {$interval}),
                billing_cycle = ?
            WHERE usuario_id = ?
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('issisi', $planId, $paymentMethod, $transactionId, $boost, $billingCycle, $usuarioId);
        $stmt->execute();

        $subscriptionId = (int) $current['id'];
        $previousPlan = (int) $current['plan_id'];
        $query = "INSERT INTO historial_suscripciones (suscripcion_id, plan_anterior, plan_nuevo, razon) VALUES (?, ?, ?, 'pago_checkout')";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('iii', $subscriptionId, $previousPlan, $planId);
        $stmt->execute();
        return;
    }

    $query = "
        INSERT INTO suscripciones
            (usuario_id, plan_id, estado, fecha_inicio, proxima_renovacion, metodo_pago, id_transaccion, auto_renovacion, visibility_boost, visibility_expires_at, billing_cycle)
        VALUES
            (?, ?, 'activa', CURDATE(), DATE_ADD(CURDATE(), INTERVAL {$interval}), ?, ?, TRUE, ?, DATE_ADD(NOW(), INTERVAL {$interval}), ?)
    ";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('iissis', $usuarioId, $planId, $paymentMethod, $transactionId, $boost, $billingCycle);
    $stmt->execute();
}

function applyVisibilityBoost($connection, $usuarioId, $plan, $boost) {
    if ($boost <= 0) {
        return;
    }

    $query = "SELECT tipo_usuario FROM usuarios WHERE id = ? LIMIT 1";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $usuarioId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        return;
    }

    $nivel = $plan['tipo'] === 'empresarial' ? 'Elite' : ($plan['tipo'] === 'premium' ? 'Elite' : 'Pro');
    $badge = ucfirst($plan['tipo']);

    $query = "
        INSERT INTO ranking_usuarios
            (usuario_id, tipo_usuario, puntos_totales, proyectos_completados, calificacion_promedio, nivel, badge, mes_actual, ano_actual)
        VALUES
            (?, ?, ?, 0, 0, ?, ?, MONTH(NOW()), YEAR(NOW()))
        ON DUPLICATE KEY UPDATE
            puntos_totales = GREATEST(puntos_totales, 0) + VALUES(puntos_totales),
            nivel = VALUES(nivel),
            badge = VALUES(badge),
            fecha_actualizacion = NOW()
    ";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('isiss', $usuarioId, $user['tipo_usuario'], $boost, $nivel, $badge);
    $stmt->execute();
}

function buildVisibilityMessage($planType, $boost) {
    if ($boost <= 0) {
        return 'Plan activo sin boost de visibilidad.';
    }

    $labels = [
        'profesional' => 'tu perfil sube en resultados y ranking con prioridad profesional',
        'premium' => 'tu perfil queda destacado y aparece por encima de perfiles basicos',
        'empresarial' => 'tu perfil obtiene maxima prioridad comercial en listados y ranking'
    ];

    return ($labels[$planType] ?? 'tu perfil recibe mayor visibilidad') . " (+{$boost} puntos).";
}

function handleUpgradePlan($input) {
    $input['billing_cycle'] = $input['billing_cycle'] ?? 'mensual';
    $input['payment_method'] = $input['payment_method'] ?? 'card_demo';
    $input['card_last4'] = $input['card_last4'] ?? '4242';
    handleCreateCheckout($input);
}

function handleCancelSubscription() {
    $usuarioId = requireUserId();
    $connection = getSubscriptionsDBConnection();

    if (!$connection) {
        respondJSON('error', 'Base de datos no disponible');
    }

    try {
        ensurePaymentSchema($connection);
        $query = "
            UPDATE suscripciones
            SET estado = 'cancelada',
                visibility_boost = 0,
                visibility_expires_at = NOW()
            WHERE usuario_id = ? AND estado = 'activa'
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();

        respondJSON('success', 'Suscripcion cancelada');
    } catch (Exception $e) {
        logError('cancel_subscription: ' . $e->getMessage());
        respondJSON('error', 'Error al cancelar suscripcion');
    } finally {
        $connection->close();
    }
}

function handleGetVisibilityStatus() {
    $usuarioId = requireUserId();
    $connection = getSubscriptionsDBConnection();

    if (!$connection) {
        respondJSON('error', 'Base de datos no disponible');
    }

    try {
        ensurePaymentSchema($connection);
        $query = "
            SELECT p.nombre, p.tipo, s.visibility_boost, s.visibility_expires_at, s.billing_cycle
            FROM suscripciones s
            JOIN planes_suscripcion p ON s.plan_id = p.id
            WHERE s.usuario_id = ? AND s.estado = 'activa'
            LIMIT 1
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        respondJSON('success', 'Visibilidad obtenida', $row ?: null);
    } catch (Exception $e) {
        logError('get_visibility_status: ' . $e->getMessage());
        respondJSON('error', 'Error al obtener visibilidad');
    } finally {
        $connection->close();
    }
}

function handleGetRanking() {
    $connection = getSubscriptionsDBConnection();

    if (!$connection) {
        respondJSON('success', 'Ranking demo obtenido', getFallbackRanking());
    }

    try {
        ensurePaymentSchema($connection);

        $tipoUsuario = sanitizeInput($_GET['tipo'] ?? 'freelancer');
        $categoria = sanitizeInput($_GET['categoria'] ?? '');
        $limit = max(1, min(50, (int) ($_GET['limit'] ?? 20)));
        $offset = max(0, (int) ($_GET['offset'] ?? 0));

        $query = "
            SELECT
                r.usuario_id,
                u.nombre,
                u.calificacion_promedio,
                u.foto_perfil,
                r.proyectos_completados,
                r.tasa_finalizacion,
                r.tiempo_respuesta_promedio,
                r.puntos_totales,
                r.posicion,
                r.nivel,
                r.badge,
                r.ingresos_totales,
                f.categoria,
                COALESCE(s.visibility_boost, 0) as visibility_boost,
                s.visibility_expires_at,
                p.nombre as plan_nombre,
                p.tipo as plan_tipo
            FROM ranking_usuarios r
            JOIN usuarios u ON r.usuario_id = u.id
            LEFT JOIN freelancers f ON u.id = f.usuario_id
            LEFT JOIN suscripciones s ON s.usuario_id = u.id
                AND s.estado = 'activa'
                AND (s.visibility_expires_at IS NULL OR s.visibility_expires_at >= NOW())
            LEFT JOIN planes_suscripcion p ON s.plan_id = p.id
            WHERE r.tipo_usuario = ?
        ";

        $params = [$tipoUsuario];
        $types = 's';

        if ($categoria) {
            $query .= " AND f.categoria = ?";
            $params[] = $categoria;
            $types .= 's';
        }

        $query .= "
            ORDER BY
                CASE WHEN COALESCE(s.visibility_boost, 0) > 0 THEN 0 ELSE 1 END,
                COALESCE(s.visibility_boost, 0) DESC,
                r.puntos_totales DESC
            LIMIT ? OFFSET ?
        ";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';

        $stmt = $connection->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();

        $ranking = [];
        while ($row = $result->fetch_assoc()) {
            $ranking[] = [
                'usuario_id' => (int) $row['usuario_id'],
                'nombre' => $row['nombre'],
                'calificacion' => (float) $row['calificacion_promedio'],
                'foto_perfil' => $row['foto_perfil'],
                'proyectos_completados' => (int) $row['proyectos_completados'],
                'tasa_finalizacion' => (float) $row['tasa_finalizacion'],
                'tiempo_respuesta_promedio' => (int) $row['tiempo_respuesta_promedio'],
                'puntos_totales' => (int) $row['puntos_totales'],
                'posicion' => (int) $row['posicion'],
                'nivel' => $row['nivel'],
                'badge' => $row['badge'],
                'ingresos_totales' => (float) $row['ingresos_totales'],
                'categoria' => $row['categoria'],
                'visibility_boost' => (int) $row['visibility_boost'],
                'visibility_expires_at' => $row['visibility_expires_at'],
                'plan_nombre' => $row['plan_nombre'],
                'plan_tipo' => $row['plan_tipo']
            ];
        }

        respondJSON('success', 'Ranking obtenido', $ranking);
    } catch (Exception $e) {
        logError('get_ranking: ' . $e->getMessage());
        respondJSON('error', 'Error al obtener ranking');
    } finally {
        $connection->close();
    }
}

function getFallbackRanking() {
    return [
        ['usuario_id' => 1, 'nombre' => 'Carlos Mendoza', 'calificacion' => 5.0, 'proyectos_completados' => 847, 'tasa_finalizacion' => 99, 'tiempo_respuesta_promedio' => 45, 'puntos_totales' => 2450, 'nivel' => 'Elite', 'badge' => 'Premium', 'visibility_boost' => 800],
        ['usuario_id' => 2, 'nombre' => 'Sofia Garcia', 'calificacion' => 4.8, 'proyectos_completados' => 320, 'tasa_finalizacion' => 96, 'tiempo_respuesta_promedio' => 120, 'puntos_totales' => 1760, 'nivel' => 'Pro', 'badge' => 'Profesional', 'visibility_boost' => 250]
    ];
}

function handleUpdateRanking() {
    $connection = getSubscriptionsDBConnection();

    if (!$connection) {
        respondJSON('error', 'Base de datos no disponible');
    }

    try {
        $usuarioId = (int) ($_POST['usuario_id'] ?? 0);
        if (!$usuarioId) {
            respondJSON('error', 'Usuario no valido');
        }

        $query = "
            SELECT
                u.tipo_usuario,
                COUNT(p.id) as proyectos_totales,
                SUM(CASE WHEN p.estado = 'completado' THEN 1 ELSE 0 END) as proyectos_completados,
                AVG(r.calificacion) as calificacion_promedio,
                MAX(COALESCE(f.respuesta_tiempo, 120)) as tiempo_respuesta_promedio
            FROM usuarios u
            LEFT JOIN proyectos p ON u.id = p.freelancer_id
            LEFT JOIN resenas r ON u.id = r.de_usuario_id
            LEFT JOIN freelancers f ON u.id = f.usuario_id
            WHERE u.id = ?
            GROUP BY u.id
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $userData = $stmt->get_result()->fetch_assoc();

        if (!$userData) {
            respondJSON('error', 'Usuario no encontrado');
        }

        $completedProjects = (int) ($userData['proyectos_completados'] ?? 0);
        $totalProjects = (int) ($userData['proyectos_totales'] ?? 0);
        $completionRate = $totalProjects > 0 ? round(($completedProjects / $totalProjects) * 100, 2) : 0;
        $responseMinutes = (int) ($userData['tiempo_respuesta_promedio'] ?? 120);
        $responseBonus = max(0, 240 - min(240, $responseMinutes));
        $basePoints = (int) ($completedProjects * 100 + ($userData['calificacion_promedio'] ?? 0) * 50 + $completionRate * 8 + $responseBonus);

        $boostQuery = "
            SELECT COALESCE(visibility_boost, 0) as boost
            FROM suscripciones
            WHERE usuario_id = ? AND estado = 'activa' AND (visibility_expires_at IS NULL OR visibility_expires_at >= NOW())
            LIMIT 1
        ";
        $stmt = $connection->prepare($boostQuery);
        $stmt->bind_param('i', $usuarioId);
        $stmt->execute();
        $boostRow = $stmt->get_result()->fetch_assoc();
        $boost = (int) ($boostRow['boost'] ?? 0);
        $points = $basePoints + $boost;

        $nivel = 'Bronce';
        if ($points >= 900) $nivel = 'Plata';
        if ($points >= 1800) $nivel = 'Pro';
        if ($points >= 5000) $nivel = 'Elite';

        $query = "
            INSERT INTO ranking_usuarios (usuario_id, tipo_usuario, puntos_totales, proyectos_completados, calificacion_promedio, tasa_finalizacion, tiempo_respuesta_promedio, nivel, mes_actual, ano_actual)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, MONTH(NOW()), YEAR(NOW()))
            ON DUPLICATE KEY UPDATE
                puntos_totales = VALUES(puntos_totales),
                proyectos_completados = VALUES(proyectos_completados),
                calificacion_promedio = VALUES(calificacion_promedio),
                tasa_finalizacion = VALUES(tasa_finalizacion),
                tiempo_respuesta_promedio = VALUES(tiempo_respuesta_promedio),
                nivel = VALUES(nivel)
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('isiiddis', $usuarioId, $userData['tipo_usuario'], $points, $completedProjects, $userData['calificacion_promedio'], $completionRate, $responseMinutes, $nivel);
        $stmt->execute();

        respondJSON('success', 'Ranking actualizado', ['puntos' => $points, 'boost' => $boost]);
    } catch (Exception $e) {
        logError('update_ranking: ' . $e->getMessage());
        respondJSON('error', 'Error al actualizar ranking');
    } finally {
        $connection->close();
    }
}
?>
