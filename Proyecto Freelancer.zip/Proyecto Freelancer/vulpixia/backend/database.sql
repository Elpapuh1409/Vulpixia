-- =====================
-- BASE DE DATOS VULPIXIA
-- =====================
-- Script para crear la estructura completa de la base de datos

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS vulpixia_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vulpixia_db;

-- =====================
-- TABLA: Usuarios
-- =====================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    tipo_usuario ENUM('cliente', 'freelancer') NOT NULL,
    foto_perfil VARCHAR(255),
    descripcion LONGTEXT,
    ubicacion VARCHAR(100),
    calificacion_promedio DECIMAL(3, 2) DEFAULT 0,
    verificado BOOLEAN DEFAULT FALSE,
    activo BOOLEAN DEFAULT TRUE,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_tipo_usuario (tipo_usuario)
);

-- =====================
-- TABLA: Freelancers
-- =====================
CREATE TABLE IF NOT EXISTS freelancers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL UNIQUE,
    categoria VARCHAR(100) NOT NULL,
    habilidades LONGTEXT,
    experiencia VARCHAR(50),
    tarifa DECIMAL(10, 2),
    tarifa_mina DECIMAL(10, 2),
    portafolio VARCHAR(255),
    descripcion LONGTEXT,
    proyectos_completados INT DEFAULT 0,
    disponible BOOLEAN DEFAULT TRUE,
    respuesta_tiempo INT,
    tasa_entrega_a_tiempo DECIMAL(5, 2),
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_categoria (categoria),
    INDEX idx_tarifa (tarifa)
);

-- =====================
-- TABLA: Clientes
-- =====================
CREATE TABLE IF NOT EXISTS clientes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL UNIQUE,
    tipo_proyecto VARCHAR(100),
    empresa VARCHAR(100),
    descripcion LONGTEXT,
    proyectos_publicados INT DEFAULT 0,
    gasto_total DECIMAL(12, 2) DEFAULT 0,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- =====================
-- TABLA: Proyectos
-- =====================
CREATE TABLE IF NOT EXISTS proyectos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id INT NOT NULL,
    freelancer_id INT,
    titulo VARCHAR(255) NOT NULL,
    descripcion LONGTEXT NOT NULL,
    categoria VARCHAR(100) NOT NULL,
    presupuesto DECIMAL(12, 2),
    estado ENUM('abierto', 'en_proceso', 'completado', 'cancelado') DEFAULT 'abierto',
    fecha_entrega DATE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_inicio TIMESTAMP,
    fecha_cierre TIMESTAMP,
    archivos_adjuntos LONGTEXT,
    puntuacion DECIMAL(3, 2),
    comentario_cierre LONGTEXT,
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (freelancer_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    INDEX idx_cliente (cliente_id),
    INDEX idx_freelancer (freelancer_id),
    INDEX idx_estado (estado),
    INDEX idx_categoria (categoria)
);

-- =====================
-- TABLA: Propuestas
-- =====================
CREATE TABLE IF NOT EXISTS propuestas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    proyecto_id INT NOT NULL,
    freelancer_id INT NOT NULL,
    monto_propuesto DECIMAL(12, 2),
    tiempo_entrega INT,
    descripcion LONGTEXT,
    estado ENUM('pendiente', 'aceptada', 'rechazada', 'retirada') DEFAULT 'pendiente',
    fecha_propuesta TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_respuesta TIMESTAMP,
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
    FOREIGN KEY (freelancer_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_proyecto (proyecto_id),
    INDEX idx_freelancer (freelancer_id),
    INDEX idx_estado (estado)
);

-- =====================
-- TABLA: Reseñas
-- =====================
CREATE TABLE IF NOT EXISTS resenas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    proyecto_id INT NOT NULL,
    usuario_id INT NOT NULL,
    de_usuario_id INT NOT NULL,
    calificacion INT CHECK (calificacion BETWEEN 1 AND 5),
    comentario LONGTEXT,
    profundidad INT CHECK (profundidad BETWEEN 1 AND 5),
    comunicacion INT CHECK (comunicacion BETWEEN 1 AND 5),
    cumplimiento INT CHECK (cumplimiento BETWEEN 1 AND 5),
    recomendacion BOOLEAN DEFAULT TRUE,
    fecha_resena TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (de_usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id),
    INDEX idx_de_usuario (de_usuario_id)
);

-- =====================
-- TABLA: Mensajes
-- =====================
CREATE TABLE IF NOT EXISTS mensajes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    remitente_id INT NOT NULL,
    destinatario_id INT NOT NULL,
    proyecto_id INT,
    contenido LONGTEXT NOT NULL,
    archivos LONGTEXT,
    leido BOOLEAN DEFAULT FALSE,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (remitente_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (destinatario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(id) ON DELETE SET NULL,
    INDEX idx_remitente (remitente_id),
    INDEX idx_destinatario (destinatario_id),
    INDEX idx_leido (leido),
    INDEX idx_conversacion (remitente_id, destinatario_id, fecha_envio)
);

-- =====================
-- TABLA: Contactos
-- =====================
CREATE TABLE IF NOT EXISTS contactos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    asunto VARCHAR(255),
    mensaje LONGTEXT NOT NULL,
    respondido BOOLEAN DEFAULT FALSE,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_respondido (respondido)
);

-- =====================
-- TABLA: Pagos
-- =====================
CREATE TABLE IF NOT EXISTS pagos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    proyecto_id INT NOT NULL,
    cliente_id INT NOT NULL,
    freelancer_id INT NOT NULL,
    monto DECIMAL(12, 2) NOT NULL,
    comision DECIMAL(12, 2),
    monto_neto DECIMAL(12, 2),
    metodo_pago VARCHAR(50),
    provider VARCHAR(50),
    provider_reference VARCHAR(255),
    estado ENUM('pendiente', 'retenido', 'entregado', 'liberado', 'completado', 'rechazado', 'reembolsado', 'disputa') DEFAULT 'pendiente',
    escrow_estado ENUM('retenido', 'entregado', 'liberado', 'reembolsado', 'disputa') DEFAULT 'retenido',
    entregable_url VARCHAR(255),
    nota_entrega LONGTEXT,
    fecha_pago TIMESTAMP,
    fecha_retenido TIMESTAMP NULL,
    fecha_entrega_real TIMESTAMP NULL,
    fecha_liberacion TIMESTAMP NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE,
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (freelancer_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_estado (estado),
    INDEX idx_fecha (fecha_pago),
    INDEX idx_cliente (cliente_id),
    INDEX idx_freelancer (freelancer_id)
);

-- =====================
-- TABLA: Portafolio
-- =====================
CREATE TABLE IF NOT EXISTS portafolio (
    id INT PRIMARY KEY AUTO_INCREMENT,
    freelancer_id INT NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    descripcion LONGTEXT,
    url_demo VARCHAR(255),
    imagen_destacada VARCHAR(255),
    categoria VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (freelancer_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_freelancer (freelancer_id)
);

-- =====================
-- TABLA: Habilidades
-- =====================
CREATE TABLE IF NOT EXISTS habilidades (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) UNIQUE NOT NULL,
    descripcion LONGTEXT,
    categoria VARCHAR(100),
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================
-- TABLA: Freelancer_Habilidades (relación muchos a muchos)
-- =====================
CREATE TABLE IF NOT EXISTS freelancer_habilidades (
    id INT PRIMARY KEY AUTO_INCREMENT,
    freelancer_id INT NOT NULL,
    habilidad_id INT NOT NULL,
    nivel INT CHECK (nivel BETWEEN 1 AND 5),
    confirmado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (freelancer_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (habilidad_id) REFERENCES habilidades(id) ON DELETE CASCADE,
    UNIQUE KEY unique_freelancer_skill (freelancer_id, habilidad_id)
);

-- =====================
-- TABLA: Ofertas Especiales
-- =====================
CREATE TABLE IF NOT EXISTS ofertas_especiales (
    id INT PRIMARY KEY AUTO_INCREMENT,
    freelancer_id INT NOT NULL,
    titulo VARCHAR(255) NOT NULL,
    descripcion LONGTEXT,
    precio DECIMAL(12, 2),
    tiempo_entrega INT,
    paquete ENUM('basico', 'estandar', 'premium') DEFAULT 'estandar',
    revisiones INT DEFAULT 1,
    activa BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (freelancer_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_freelancer (freelancer_id)
);

-- =====================
-- TABLA: Notificaciones
-- =====================
CREATE TABLE IF NOT EXISTS notificaciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    tipo VARCHAR(50),
    titulo VARCHAR(255),
    mensaje LONGTEXT,
    enlace VARCHAR(255),
    leida BOOLEAN DEFAULT FALSE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id),
    INDEX idx_leida (leida)
);

-- =====================
-- TABLA: Tokens de Verificación
-- =====================
CREATE TABLE IF NOT EXISTS tokens_verificacion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    token VARCHAR(255) UNIQUE NOT NULL,
    tipo ENUM('email', 'password_reset') DEFAULT 'email',
    usado BOOLEAN DEFAULT FALSE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_expiracion TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_token (token)
);

-- =====================
-- TABLA: Planes de Suscripción (Tipos de membresías)
-- =====================
CREATE TABLE IF NOT EXISTS planes_suscripcion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    tipo ENUM('basico', 'profesional', 'premium', 'empresarial') NOT NULL,
    precio DECIMAL(10, 2) NOT NULL,
    moneda VARCHAR(3) DEFAULT 'USD',
    limite_proyectos INT,
    limite_propuestas INT,
    limite_almacenamiento INT,
    descripcion LONGTEXT,
    caracteristicas LONGTEXT,
    prioridad_soporte INT,
    descuento_comision DECIMAL(5, 2) DEFAULT 0,
    activo BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tipo (tipo)
);

-- =====================
-- TABLA: Suscripciones de Usuarios
-- =====================
CREATE TABLE IF NOT EXISTS suscripciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL UNIQUE,
    plan_id INT NOT NULL,
    estado ENUM('activa', 'suspendida', 'cancelada') DEFAULT 'activa',
    fecha_inicio DATE NOT NULL,
    fecha_finalizacion DATE,
    proxima_renovacion DATE,
    metodo_pago VARCHAR(50),
    id_transaccion VARCHAR(255),
    billing_cycle ENUM('mensual', 'anual') DEFAULT 'mensual',
    visibility_boost INT DEFAULT 0,
    visibility_expires_at DATETIME NULL,
    auto_renovacion BOOLEAN DEFAULT TRUE,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultima_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES planes_suscripcion(id) ON DELETE RESTRICT,
    INDEX idx_usuario (usuario_id),
    INDEX idx_estado (estado),
    INDEX idx_renovacion (proxima_renovacion)
);

-- =====================
-- TABLA: Pagos de Suscripcion
-- =====================
CREATE TABLE IF NOT EXISTS pagos_suscripcion (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    plan_id INT NOT NULL,
    ciclo ENUM('mensual', 'anual') DEFAULT 'mensual',
    monto DECIMAL(10, 2) NOT NULL,
    moneda VARCHAR(3) DEFAULT 'USD',
    metodo_pago VARCHAR(50) NOT NULL,
    estado ENUM('pendiente', 'aprobado', 'rechazado', 'reembolsado') DEFAULT 'pendiente',
    referencia VARCHAR(255) UNIQUE,
    tarjeta_ultimos4 VARCHAR(4),
    fecha_pago TIMESTAMP NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES planes_suscripcion(id) ON DELETE RESTRICT,
    INDEX idx_usuario (usuario_id),
    INDEX idx_estado (estado),
    INDEX idx_referencia (referencia)
);

-- =====================
-- TABLA: Historial de Suscripciones
-- =====================
CREATE TABLE IF NOT EXISTS historial_suscripciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    suscripcion_id INT NOT NULL,
    plan_anterior INT,
    plan_nuevo INT NOT NULL,
    razon VARCHAR(255),
    fecha_cambio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (suscripcion_id) REFERENCES suscripciones(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_anterior) REFERENCES planes_suscripcion(id) ON DELETE SET NULL,
    FOREIGN KEY (plan_nuevo) REFERENCES planes_suscripcion(id) ON DELETE CASCADE,
    INDEX idx_suscripcion (suscripcion_id)
);

-- =====================
-- TABLA: Términos Aceptados (Registro Legal)
-- =====================
CREATE TABLE IF NOT EXISTS terminos_aceptados (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    version_terminos VARCHAR(10) NOT NULL,
    version_privacidad VARCHAR(10) NOT NULL,
    terminos_aceptados BOOLEAN DEFAULT FALSE,
    privacidad_aceptada BOOLEAN DEFAULT FALSE,
    marketing_aceptado BOOLEAN DEFAULT FALSE,
    fecha_aceptacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_aceptacion VARCHAR(45),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id)
);

-- =====================
-- TABLA: Ranking de Usuarios (Actualizado automáticamente)
-- =====================
CREATE TABLE IF NOT EXISTS ranking_usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL UNIQUE,
    tipo_usuario ENUM('freelancer', 'cliente') NOT NULL,
    puntos_totales INT DEFAULT 0,
    proyectos_completados INT DEFAULT 0,
    calificacion_promedio DECIMAL(3, 2) DEFAULT 0,
    tasa_finalizacion DECIMAL(5, 2) DEFAULT 0,
    tiempo_respuesta_promedio INT DEFAULT 0,
    ingresos_totales DECIMAL(12, 2) DEFAULT 0,
    nivel VARCHAR(50),
    badge VARCHAR(50),
    posicion INT,
    mes_actual INT,
    ano_actual INT,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_nivel (nivel),
    INDEX idx_posicion (posicion)
);

-- =====================
-- TABLA: Historial de Ranking (Seguimiento mensual)
-- =====================
CREATE TABLE IF NOT EXISTS historial_ranking (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT NOT NULL,
    posicion INT,
    puntos INT,
    mes INT,
    ano INT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_usuario (usuario_id),
    INDEX idx_periodo (ano, mes)
);

-- =====================
-- INSERCIONES DE EJEMPLO (Opcional)
-- =====================

-- Insertar planes de suscripción
INSERT INTO planes_suscripcion (nombre, tipo, precio, limite_proyectos, limite_propuestas, limite_almacenamiento, descripcion, descuento_comision, prioridad_soporte) VALUES
('Básico', 'basico', 0.00, 3, 5, 1, 'Plan gratuito para comenzar', 0, 3),
('Profesional', 'profesional', 9.99, 20, 50, 10, 'Para freelancers activos', 5, 2),
('Premium', 'premium', 24.99, 100, 500, 50, 'Para freelancers que crecen', 10, 1),
('Empresarial', 'empresarial', 99.99, 999, 9999, 500, 'Solución completa para equipos', 15, 1);

-- Insertar habilidades de ejemplo
INSERT INTO habilidades (nombre, categoria) VALUES
('React', 'Frontend'),
('Node.js', 'Backend'),
('MongoDB', 'Database'),
('JavaScript', 'Lenguaje'),
('Python', 'Lenguaje'),
('Figma', 'Diseño'),
('Adobe XD', 'Diseño'),
('Photoshop', 'Diseño'),
('MySQL', 'Database'),
('PostgreSQL', 'Database'),
('AWS', 'Cloud'),
('Docker', 'DevOps'),
('Git', 'Control de versiones'),
('HTML/CSS', 'Frontend'),
('Vue.js', 'Frontend');

-- =====================
-- FIN DEL SCRIPT
-- =====================
