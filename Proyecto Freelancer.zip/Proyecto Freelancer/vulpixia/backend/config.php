<?php
/**
 * Configuración de la Base de Datos - Vulpixia
 * Este archivo contiene la configuración para conectarse a MySQL
 */

// Configuración de conexión a la base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'vulpixia_db');
define('DB_PORT', 3306);

// Configuración de la aplicación
define('SITE_URL', 'http://localhost/vulpixia/');
define('SITE_NAME', 'Vulpixia');

// Configuración de seguridad
define('SESSION_TIMEOUT', 3600); // 1 hora en segundos
define('PASSWORD_MIN_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_ATTEMPT_TIMEOUT', 900); // 15 minutos

// Configuración de email
define('MAIL_FROM', 'noreply@vulpixia.com');
define('MAIL_FROM_NAME', 'Vulpixia');

// Configuración de archivos
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);
define('MAX_UPLOAD_SIZE', 5242880); // 5MB

// Configuración de tokens
define('TOKEN_LENGTH', 32);
define('TOKEN_EXPIRY', 86400); // 24 horas

// Errores
define('DISPLAY_ERRORS', true);
define('LOG_ERRORS', true);
define('ERROR_LOG_FILE', __DIR__ . '/../logs/error.log');

// Iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Función para conectar a la base de datos
 */
function getDBConnection() {
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
        
        if ($conn->connect_error) {
            throw new Exception("Error de conexión: " . $conn->connect_error);
        }
        
        // Establecer charset UTF-8
        $conn->set_charset("utf8mb4");
        
        return $conn;
    } catch (Exception $e) {
        logError($e->getMessage());
        die("Error de conexión a la base de datos.");
    }
}

/**
 * Función para registrar errores
 */
function logError($message) {
    if (LOG_ERRORS) {
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] $message\n";
        error_log($log_message, 3, ERROR_LOG_FILE);
    }
}

/**
 * Función para responder JSON
 */
function respondJSON($status, $message = '', $data = []) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => $status,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

/**
 * Función para validar email
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Función para validar contraseña
 */
function isValidPassword($password) {
    return strlen($password) >= PASSWORD_MIN_LENGTH;
}

/**
 * Función para sanitizar entrada
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * Alias corto usado por algunos módulos antiguos.
 */
function sanitize($input) {
    return sanitizeInput($input);
}

/**
 * Función para verificar si el usuario está autenticado
 */
function isAuthenticated() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Función para obtener el usuario actual
 */
function getCurrentUser() {
    if (isAuthenticated()) {
        return $_SESSION['user_id'];
    }
    return null;
}

/**
 * Función para generar token seguro
 */
function generateToken($length = TOKEN_LENGTH) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Función para hashear contraseña
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

/**
 * Función para verificar contraseña
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Función para redirigir
 */
function redirect($url) {
    header("Location: " . $url);
    exit;
}

/**
 * Función para establecer mensaje de sesión
 */
function setSessionMessage($type, $message) {
    $_SESSION['message'] = [
        'type' => $type,
        'text' => $message
    ];
}

/**
 * Función para obtener y limpiar mensaje de sesión
 */
function getSessionMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        unset($_SESSION['message']);
        return $message;
    }
    return null;
}

?>
