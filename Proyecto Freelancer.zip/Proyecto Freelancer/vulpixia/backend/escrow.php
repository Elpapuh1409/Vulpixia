<?php
/**
 * Pagos retenidos cliente-freelancer - Vulpixia
 * Flujo marketplace: cliente paga, plataforma retiene, freelancer entrega, cliente libera.
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = $_POST;
}

$action = $_GET['action'] ?? $_POST['action'] ?? ($input['action'] ?? '');

if (!isAuthenticated()) {
    respondJSON('error', 'Debes iniciar sesion para gestionar pagos de proyecto');
}

$currentUserId = (int) getCurrentUser();

switch ($action) {
    case 'list_freelancers':
        handleListFreelancers();
        break;
    case 'create_escrow':
        handleCreateEscrow($currentUserId, $input);
        break;
    case 'list_escrows':
        handleListEscrows($currentUserId);
        break;
    case 'deliver_work':
        handleDeliverWork($currentUserId, $input);
        break;
    case 'release_payment':
        handleReleasePayment($currentUserId, $input);
        break;
    case 'refund_payment':
        handleRefundPayment($currentUserId, $input);
        break;
    default:
        respondJSON('error', 'Accion no valida');
}

function ensureEscrowSchema($connection) {
    $connection->query("
        CREATE TABLE IF NOT EXISTS pagos (
            id INT PRIMARY KEY AUTO_INCREMENT,
            proyecto_id INT NOT NULL,
            cliente_id INT NOT NULL,
            freelancer_id INT NOT NULL,
            monto DECIMAL(12, 2) NOT NULL,
            comision DECIMAL(12, 2),
            monto_neto DECIMAL(12, 2),
            metodo_pago VARCHAR(50),
            provider VARCHAR(50),
            provider_reference VARCHAR(255),
            estado ENUM('pendiente', 'retenido', 'entregado', 'liberado', 'completado', 'rechazado', 'reembolsado', 'disputa') DEFAULT 'pendiente',
            escrow_estado ENUM('retenido', 'entregado', 'liberado', 'reembolsado', 'disputa') DEFAULT 'retenido',
            entregable_url VARCHAR(255),
            nota_entrega LONGTEXT,
            fecha_pago TIMESTAMP NULL,
            fecha_retenido TIMESTAMP NULL,
            fecha_entrega_real TIMESTAMP NULL,
            fecha_liberacion TIMESTAMP NULL,
            fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_estado (estado),
            INDEX idx_fecha (fecha_pago),
            INDEX idx_cliente (cliente_id),
            INDEX idx_freelancer (freelancer_id)
        )
    ");

    $connection->query("
        ALTER TABLE pagos
        MODIFY estado ENUM('pendiente', 'retenido', 'entregado', 'liberado', 'completado', 'rechazado', 'reembolsado', 'disputa') DEFAULT 'pendiente'
    ");

    addColumnIfMissingEscrow($connection, 'pagos', 'provider', "VARCHAR(50)");
    addColumnIfMissingEscrow($connection, 'pagos', 'provider_reference', "VARCHAR(255)");
    addColumnIfMissingEscrow($connection, 'pagos', 'escrow_estado', "ENUM('retenido', 'entregado', 'liberado', 'reembolsado', 'disputa') DEFAULT 'retenido'");
    addColumnIfMissingEscrow($connection, 'pagos', 'entregable_url', "VARCHAR(255)");
    addColumnIfMissingEscrow($connection, 'pagos', 'nota_entrega', "LONGTEXT");
    addColumnIfMissingEscrow($connection, 'pagos', 'fecha_retenido', "TIMESTAMP NULL");
    addColumnIfMissingEscrow($connection, 'pagos', 'fecha_entrega_real', "TIMESTAMP NULL");
    addColumnIfMissingEscrow($connection, 'pagos', 'fecha_liberacion', "TIMESTAMP NULL");
}

function addColumnIfMissingEscrow($connection, $table, $column, $definition) {
    $query = "
        SELECT COUNT(*) as total
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?
    ";
    $stmt = $connection->prepare($query);
    $dbName = DB_NAME;
    $stmt->bind_param('sss', $dbName, $table, $column);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if ((int) $result['total'] === 0) {
        $connection->query("ALTER TABLE {$table} ADD COLUMN {$column} {$definition}");
    }
}

function handleListFreelancers() {
    $connection = getDBConnection();
    ensureEscrowSchema($connection);

    $query = "
        SELECT id, nombre, email, tipo_usuario, foto_perfil
        FROM usuarios
        WHERE tipo_usuario = 'freelancer' AND activo = TRUE
        ORDER BY nombre ASC
        LIMIT 50
    ";
    $result = $connection->query($query);

    $freelancers = [];
    while ($row = $result->fetch_assoc()) {
        $freelancers[] = normalizeUserEscrow($row);
    }

    $connection->close();
    respondJSON('success', 'Freelancers obtenidos', $freelancers);
}

function handleCreateEscrow($currentUserId, $input) {
    $freelancerId = (int) ($input['freelancer_id'] ?? 0);
    $amount = round((float) ($input['amount'] ?? 0), 2);
    $title = sanitizeInput($input['title'] ?? '');
    $description = sanitizeInput($input['description'] ?? '');
    $category = sanitizeInput($input['category'] ?? 'general');
    $dueDate = sanitizeInput($input['due_date'] ?? '');
    $provider = sanitizeInput($input['provider'] ?? 'stripe_demo');

    if (!in_array($provider, ['stripe_demo', 'paypal_demo'], true)) {
        respondJSON('error', 'Proveedor de pago no valido');
    }

    if ($freelancerId <= 0 || $freelancerId === $currentUserId) {
        respondJSON('error', 'Selecciona un freelancer valido');
    }

    if ($amount < 5) {
        respondJSON('error', 'El monto minimo para retener es 5 USD');
    }

    if ($title === '' || $description === '') {
        respondJSON('error', 'Titulo y descripcion son obligatorios');
    }

    $connection = getDBConnection();
    ensureEscrowSchema($connection);

    $freelancer = getEscrowUser($connection, $freelancerId, 'freelancer');
    if (!$freelancer) {
        $connection->close();
        respondJSON('error', 'Freelancer no encontrado');
    }

    $connection->begin_transaction();

    try {
        $fechaEntrega = $dueDate ?: null;
        $query = "
            INSERT INTO proyectos
                (cliente_id, freelancer_id, titulo, descripcion, categoria, presupuesto, estado, fecha_entrega, fecha_inicio)
            VALUES (?, ?, ?, ?, ?, ?, 'en_proceso', ?, NOW())
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('iisssds', $currentUserId, $freelancerId, $title, $description, $category, $amount, $fechaEntrega);
        $stmt->execute();
        $projectId = (int) $connection->insert_id;

        $commission = round($amount * 0.10, 2);
        $netAmount = round($amount - $commission, 2);
        $reference = strtoupper(($provider === 'paypal_demo' ? 'PAYPAL' : 'STRIPE') . '-ESC-' . bin2hex(random_bytes(4)));
        $paymentMethod = $provider === 'paypal_demo' ? 'paypal' : 'stripe';

        $query = "
            INSERT INTO pagos
                (proyecto_id, cliente_id, freelancer_id, monto, comision, monto_neto, metodo_pago, provider, provider_reference, estado, escrow_estado, fecha_pago, fecha_retenido)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'retenido', 'retenido', NOW(), NOW())
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('iiidddsss', $projectId, $currentUserId, $freelancerId, $amount, $commission, $netAmount, $paymentMethod, $provider, $reference);
        $stmt->execute();
        $paymentId = (int) $connection->insert_id;

        $connection->commit();

        respondJSON('success', 'Pago recibido y retenido por Vulpixia', [
            'payment_id' => $paymentId,
            'project_id' => $projectId,
            'provider_reference' => $reference,
            'amount' => $amount,
            'commission' => $commission,
            'net_amount' => $netAmount,
            'status' => 'retenido'
        ]);
    } catch (Exception $e) {
        $connection->rollback();
        logError('create_escrow: ' . $e->getMessage());
        respondJSON('error', 'No se pudo crear el pago retenido');
    } finally {
        $connection->close();
    }
}

function handleListEscrows($currentUserId) {
    $connection = getDBConnection();
    ensureEscrowSchema($connection);

    $query = "
        SELECT
            p.*,
            pr.titulo as proyecto_titulo,
            pr.descripcion as proyecto_descripcion,
            pr.fecha_entrega,
            cliente.nombre as cliente_nombre,
            freelancer.nombre as freelancer_nombre
        FROM pagos p
        JOIN proyectos pr ON p.proyecto_id = pr.id
        JOIN usuarios cliente ON p.cliente_id = cliente.id
        JOIN usuarios freelancer ON p.freelancer_id = freelancer.id
        WHERE p.cliente_id = ? OR p.freelancer_id = ?
        ORDER BY p.fecha_creacion DESC
        LIMIT 50
    ";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('ii', $currentUserId, $currentUserId);
    $stmt->execute();
    $result = $stmt->get_result();

    $payments = [];
    while ($row = $result->fetch_assoc()) {
        $payments[] = normalizeEscrow($row, $currentUserId);
    }

    $connection->close();
    respondJSON('success', 'Pagos retenidos obtenidos', $payments);
}

function handleDeliverWork($currentUserId, $input) {
    $paymentId = (int) ($input['payment_id'] ?? 0);
    $deliveryNote = sanitizeInput($input['delivery_note'] ?? '');
    $deliveryUrl = sanitizeInput($input['delivery_url'] ?? '');

    if ($paymentId <= 0 || $deliveryNote === '') {
        respondJSON('error', 'Selecciona un pago y agrega una nota de entrega');
    }

    $connection = getDBConnection();
    ensureEscrowSchema($connection);

    $payment = getEscrowPayment($connection, $paymentId);
    if (!$payment || (int) $payment['freelancer_id'] !== $currentUserId) {
        $connection->close();
        respondJSON('error', 'No tienes permiso para entregar este proyecto');
    }

    if (!in_array($payment['escrow_estado'], ['retenido'], true)) {
        $connection->close();
        respondJSON('error', 'Este pago no esta en estado retenido');
    }

    $query = "
        UPDATE pagos
        SET estado = 'entregado',
            escrow_estado = 'entregado',
            nota_entrega = ?,
            entregable_url = ?,
            fecha_entrega_real = NOW()
        WHERE id = ?
    ";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('ssi', $deliveryNote, $deliveryUrl, $paymentId);
    $stmt->execute();
    $connection->close();

    respondJSON('success', 'Entrega registrada. El cliente ya puede liberar el pago.');
}

function handleReleasePayment($currentUserId, $input) {
    $paymentId = (int) ($input['payment_id'] ?? 0);

    if ($paymentId <= 0) {
        respondJSON('error', 'Pago no valido');
    }

    $connection = getDBConnection();
    ensureEscrowSchema($connection);

    $payment = getEscrowPayment($connection, $paymentId);
    if (!$payment || (int) $payment['cliente_id'] !== $currentUserId) {
        $connection->close();
        respondJSON('error', 'No tienes permiso para liberar este pago');
    }

    if ($payment['escrow_estado'] !== 'entregado') {
        $connection->close();
        respondJSON('error', 'El freelancer debe marcar la entrega antes de liberar');
    }

    $connection->begin_transaction();

    try {
        $query = "
            UPDATE pagos
            SET estado = 'liberado',
                escrow_estado = 'liberado',
                fecha_liberacion = NOW()
            WHERE id = ?
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $paymentId);
        $stmt->execute();

        $query = "UPDATE proyectos SET estado = 'completado', fecha_cierre = NOW() WHERE id = ?";
        $stmt = $connection->prepare($query);
        $projectId = (int) $payment['proyecto_id'];
        $stmt->bind_param('i', $projectId);
        $stmt->execute();

        $connection->commit();
        respondJSON('success', 'Pago liberado al freelancer', [
            'payment_id' => $paymentId,
            'net_amount' => (float) $payment['monto_neto']
        ]);
    } catch (Exception $e) {
        $connection->rollback();
        logError('release_payment: ' . $e->getMessage());
        respondJSON('error', 'No se pudo liberar el pago');
    } finally {
        $connection->close();
    }
}

function handleRefundPayment($currentUserId, $input) {
    $paymentId = (int) ($input['payment_id'] ?? 0);

    if ($paymentId <= 0) {
        respondJSON('error', 'Pago no valido');
    }

    $connection = getDBConnection();
    ensureEscrowSchema($connection);

    $payment = getEscrowPayment($connection, $paymentId);
    if (!$payment || (int) $payment['cliente_id'] !== $currentUserId) {
        $connection->close();
        respondJSON('error', 'No tienes permiso para reembolsar este pago');
    }

    if ($payment['escrow_estado'] === 'liberado') {
        $connection->close();
        respondJSON('error', 'Un pago liberado no puede reembolsarse desde este flujo');
    }

    $query = "UPDATE pagos SET estado = 'reembolsado', escrow_estado = 'reembolsado' WHERE id = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $paymentId);
    $stmt->execute();

    $query = "UPDATE proyectos SET estado = 'cancelado', fecha_cierre = NOW() WHERE id = ?";
    $stmt = $connection->prepare($query);
    $projectId = (int) $payment['proyecto_id'];
    $stmt->bind_param('i', $projectId);
    $stmt->execute();

    $connection->close();
    respondJSON('success', 'Pago reembolsado al cliente');
}

function getEscrowUser($connection, $userId, $type = null) {
    if ($type) {
        $query = "SELECT id, nombre, email, tipo_usuario, foto_perfil FROM usuarios WHERE id = ? AND tipo_usuario = ? AND activo = TRUE LIMIT 1";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('is', $userId, $type);
    } else {
        $query = "SELECT id, nombre, email, tipo_usuario, foto_perfil FROM usuarios WHERE id = ? AND activo = TRUE LIMIT 1";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $userId);
    }

    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function getEscrowPayment($connection, $paymentId) {
    $query = "SELECT * FROM pagos WHERE id = ? LIMIT 1";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $paymentId);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function normalizeUserEscrow($row) {
    return [
        'id' => (int) $row['id'],
        'name' => $row['nombre'],
        'email' => $row['email'],
        'type' => $row['tipo_usuario'],
        'avatar' => $row['foto_perfil'] ?: null
    ];
}

function normalizeEscrow($row, $currentUserId) {
    return [
        'id' => (int) $row['id'],
        'project_id' => (int) $row['proyecto_id'],
        'title' => $row['proyecto_titulo'],
        'description' => $row['proyecto_descripcion'],
        'client' => $row['cliente_nombre'],
        'freelancer' => $row['freelancer_nombre'],
        'amount' => (float) $row['monto'],
        'commission' => (float) $row['comision'],
        'net_amount' => (float) $row['monto_neto'],
        'provider' => $row['provider'] ?: $row['metodo_pago'],
        'reference' => $row['provider_reference'],
        'status' => $row['escrow_estado'] ?: $row['estado'],
        'delivery_note' => html_entity_decode($row['nota_entrega'] ?? '', ENT_QUOTES, 'UTF-8'),
        'delivery_url' => $row['entregable_url'],
        'due_date' => $row['fecha_entrega'],
        'created_at' => $row['fecha_creacion'],
        'delivered_at' => $row['fecha_entrega_real'],
        'released_at' => $row['fecha_liberacion'],
        'role' => (int) $row['cliente_id'] === $currentUserId ? 'cliente' : 'freelancer'
    ];
}
?>
