<?php
/**
 * Manejadores de Formularios - Vulpixia
 * Procesa los formularios enviados desde el frontend
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

header('Content-Type: application/json; charset=utf-8');

// Obtener acción a realizar
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Instanciar base de datos
$db = new Database();

// Enrutador de acciones
switch ($action) {
    case 'register':
        handleRegister();
        break;
    case 'login':
        handleLogin();
        break;
    case 'logout':
        handleLogout();
        break;
    case 'contact':
        handleContact();
        break;
    case 'search_freelancers':
        handleSearchFreelancers();
        break;
    case 'get_freelancer':
        handleGetFreelancer();
        break;
    case 'create_project':
        handleCreateProject();
        break;
    case 'update_profile':
        handleUpdateProfile();
        break;
    default:
        respondJSON('error', 'Acción no válida');
}

/**
 * Manejo del registro de usuarios
 */
function handleRegister() {
    global $db;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        respondJSON('error', 'Método no permitido');
    }
    
    $nombre = sanitizeInput($_POST['nombre'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $tipo_usuario = sanitizeInput($_POST['tipo_usuario'] ?? '');
    
    // Validaciones
    if (empty($nombre) || empty($email) || empty($password) || empty($tipo_usuario)) {
        respondJSON('error', 'Todos los campos son obligatorios');
    }
    
    if (!isValidEmail($email)) {
        respondJSON('error', 'El correo electrónico no es válido');
    }
    
    if ($password !== $confirmPassword) {
        respondJSON('error', 'Las contraseñas no coinciden');
    }
    
    if (!isValidPassword($password)) {
        respondJSON('error', 'La contraseña debe tener al menos 6 caracteres');
    }
    
    if ($tipo_usuario !== 'cliente' && $tipo_usuario !== 'freelancer') {
        respondJSON('error', 'Tipo de usuario no válido');
    }
    
    // Datos adicionales según tipo
    $datos_adicionales = [];
    
    if ($tipo_usuario === 'freelancer') {
        $datos_adicionales = [
            'categoria' => sanitizeInput($_POST['categoria'] ?? ''),
            'habilidades' => sanitizeInput($_POST['habilidades'] ?? ''),
            'experiencia' => sanitizeInput($_POST['experiencia'] ?? ''),
            'tarifa' => floatval($_POST['tarifa'] ?? 0),
            'portafolio' => sanitizeInput($_POST['portafolio'] ?? '')
        ];
    } elseif ($tipo_usuario === 'cliente') {
        $datos_adicionales = [
            'tipo_proyecto' => sanitizeInput($_POST['tipo_proyecto'] ?? '')
        ];
    }
    
    // Registrar usuario
    $resultado = $db->registerUser($nombre, $email, $password, $tipo_usuario, $datos_adicionales);
    
    if ($resultado['success']) {
        // Iniciar sesión automáticamente
        $_SESSION['user_id'] = $resultado['user_id'];
        $_SESSION['user_name'] = $nombre;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_type'] = $tipo_usuario;
        
        respondJSON('success', 'Cuenta creada exitosamente', [
            'user_id' => $resultado['user_id'],
            'nombre' => $nombre,
            'tipo_usuario' => $tipo_usuario
        ]);
    } else {
        respondJSON('error', $resultado['error']);
    }
}

/**
 * Manejo del login
 */
function handleLogin() {
    global $db;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        respondJSON('error', 'Método no permitido');
    }
    
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        respondJSON('error', 'Email y contraseña son obligatorios');
    }
    
    if (!isValidEmail($email)) {
        respondJSON('error', 'El correo electrónico no es válido');
    }
    
    $resultado = $db->loginUser($email, $password);
    
    if ($resultado['success']) {
        // Crear sesión
        $_SESSION['user_id'] = $resultado['user_id'];
        $_SESSION['user_name'] = $resultado['nombre'];
        $_SESSION['user_email'] = $resultado['email'];
        $_SESSION['user_type'] = $resultado['tipo_usuario'];
        $_SESSION['login_time'] = time();
        
        respondJSON('success', 'Login exitoso', $resultado);
    } else {
        respondJSON('error', $resultado['error']);
    }
}

/**
 * Manejo del logout
 */
function handleLogout() {
    session_destroy();
    respondJSON('success', 'Sesión cerrada');
}

/**
 * Manejo del formulario de contacto
 */
function handleContact() {
    global $db;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        respondJSON('error', 'Método no permitido');
    }
    
    $nombre = sanitizeInput($_POST['nombre'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $mensaje = sanitizeInput($_POST['mensaje'] ?? '');
    
    if (empty($nombre) || empty($email) || empty($mensaje)) {
        respondJSON('error', 'Todos los campos son obligatorios');
    }
    
    if (!isValidEmail($email)) {
        respondJSON('error', 'El correo electrónico no es válido');
    }
    
    if (strlen($mensaje) < 10) {
        respondJSON('error', 'El mensaje debe tener al menos 10 caracteres');
    }
    
    if ($db->insertContactMessage($nombre, $email, $mensaje)) {
        // Aquí se podría enviar un email
        respondJSON('success', 'Mensaje enviado exitosamente');
    } else {
        respondJSON('error', 'Error al enviar el mensaje');
    }
}

/**
 * Búsqueda de freelancers
 */
function handleSearchFreelancers() {
    global $db;
    
    $query = sanitizeInput($_GET['q'] ?? '');
    $category = sanitizeInput($_GET['category'] ?? '');
    $page = intval($_GET['page'] ?? 1);
    $limit = 10;
    $offset = ($page - 1) * $limit;
    
    if (empty($query) && empty($category)) {
        respondJSON('error', 'Debe proporcionar un término de búsqueda o categoría');
    }
    
    $freelancers = [];
    
    if (!empty($category)) {
        $freelancers = $db->getFreelancersByCategory($category, $limit, $offset);
    } elseif (!empty($query)) {
        $freelancers = $db->searchFreelancers($query, $limit, $offset);
    }
    
    respondJSON('success', 'Búsqueda completada', [
        'freelancers' => $freelancers,
        'total' => count($freelancers),
        'page' => $page
    ]);
}

/**
 * Obtener datos de un freelancer específico
 */
function handleGetFreelancer() {
    global $db;
    
    $freelancer_id = intval($_GET['id'] ?? 0);
    
    if ($freelancer_id === 0) {
        respondJSON('error', 'ID de freelancer no válido');
    }
    
    $freelancer = $db->getUserData($freelancer_id);
    
    if (!$freelancer) {
        respondJSON('error', 'Freelancer no encontrado');
    }
    
    respondJSON('success', 'Datos del freelancer obtenidos', $freelancer);
}

/**
 * Crear proyecto
 */
function handleCreateProject() {
    global $db;
    
    if (!isAuthenticated()) {
        respondJSON('error', 'Debes estar autenticado');
    }
    
    if ($_SESSION['user_type'] !== 'cliente') {
        respondJSON('error', 'Solo los clientes pueden crear proyectos');
    }
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        respondJSON('error', 'Método no permitido');
    }
    
    $titulo = sanitizeInput($_POST['titulo'] ?? '');
    $descripcion = sanitizeInput($_POST['descripcion'] ?? '');
    $categoria = sanitizeInput($_POST['categoria'] ?? '');
    $presupuesto = floatval($_POST['presupuesto'] ?? 0);
    $fecha_entrega = sanitizeInput($_POST['fecha_entrega'] ?? '');
    
    if (empty($titulo) || empty($descripcion) || empty($categoria)) {
        respondJSON('error', 'Todos los campos son obligatorios');
    }
    
    $resultado = $db->insertProject(
        getCurrentUser(),
        $titulo,
        $descripcion,
        $categoria,
        $presupuesto,
        $fecha_entrega
    );
    
    if ($resultado['success']) {
        respondJSON('success', 'Proyecto creado exitosamente', $resultado);
    } else {
        respondJSON('error', $resultado['error']);
    }
}

/**
 * Actualizar perfil de usuario
 */
function handleUpdateProfile() {
    global $db;
    
    if (!isAuthenticated()) {
        respondJSON('error', 'Debes estar autenticado');
    }
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        respondJSON('error', 'Método no permitido');
    }
    
    $datos = [
        'nombre' => sanitizeInput($_POST['nombre'] ?? '')
    ];
    
    if (empty($datos['nombre'])) {
        respondJSON('error', 'El nombre es obligatorio');
    }
    
    if ($db->updateUserProfile(getCurrentUser(), $datos)) {
        $_SESSION['user_name'] = $datos['nombre'];
        respondJSON('success', 'Perfil actualizado exitosamente');
    } else {
        respondJSON('error', 'Error al actualizar el perfil');
    }
}

?>
