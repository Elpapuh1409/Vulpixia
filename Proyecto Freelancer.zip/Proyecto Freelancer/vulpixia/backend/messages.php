<?php
/**
 * Mensajeria cliente-freelancer - Vulpixia
 * Chat estilo WhatsApp con AJAX + polling e historial en MySQL.
 */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

$action = $_GET['action'] ?? $_POST['action'] ?? ($input['action'] ?? '');

if (!isAuthenticated()) {
    respondJSON('error', 'Debes iniciar sesion para usar el chat');
}

$currentUserId = (int) getCurrentUser();

switch ($action) {
    case 'me':
        handleCurrentUser($currentUserId);
        break;
    case 'list_conversations':
        handleListConversations($currentUserId);
        break;
    case 'list_contacts':
        handleListContacts($currentUserId);
        break;
    case 'get_messages':
        handleGetMessages($currentUserId);
        break;
    case 'send_message':
        handleSendMessage($currentUserId, $input);
        break;
    case 'mark_read':
        handleMarkRead($currentUserId, $input);
        break;
    default:
        respondJSON('error', 'Accion no valida');
}

function ensureMessagesSchema($connection) {
    $connection->query("
        CREATE TABLE IF NOT EXISTS mensajes (
            id INT PRIMARY KEY AUTO_INCREMENT,
            remitente_id INT NOT NULL,
            destinatario_id INT NOT NULL,
            proyecto_id INT,
            contenido LONGTEXT NOT NULL,
            archivos LONGTEXT,
            leido BOOLEAN DEFAULT FALSE,
            fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_remitente (remitente_id),
            INDEX idx_destinatario (destinatario_id),
            INDEX idx_leido (leido),
            INDEX idx_conversacion (remitente_id, destinatario_id, fecha_envio)
        )
    ");
}

function handleCurrentUser($currentUserId) {
    $connection = getDBConnection();
    ensureMessagesSchema($connection);

    $query = "SELECT id, nombre, email, tipo_usuario, foto_perfil FROM usuarios WHERE id = ? LIMIT 1";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $currentUserId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $connection->close();

    if (!$user) {
        respondJSON('error', 'Usuario no encontrado');
    }

    respondJSON('success', 'Usuario actual', normalizeUser($user));
}

function handleListConversations($currentUserId) {
    $connection = getDBConnection();
    ensureMessagesSchema($connection);

    $query = "
        SELECT
            u.id,
            u.nombre,
            u.email,
            u.tipo_usuario,
            u.foto_perfil,
            last_msg.contenido as ultimo_mensaje,
            last_msg.fecha_envio as ultima_fecha,
            COALESCE(unread.no_leidos, 0) as no_leidos
        FROM usuarios u
        JOIN (
            SELECT
                CASE
                    WHEN remitente_id = ? THEN destinatario_id
                    ELSE remitente_id
                END as contacto_id,
                MAX(id) as ultimo_id
            FROM mensajes
            WHERE remitente_id = ? OR destinatario_id = ?
            GROUP BY contacto_id
        ) conv ON conv.contacto_id = u.id
        JOIN mensajes last_msg ON last_msg.id = conv.ultimo_id
        LEFT JOIN (
            SELECT remitente_id, COUNT(*) as no_leidos
            FROM mensajes
            WHERE destinatario_id = ? AND leido = FALSE
            GROUP BY remitente_id
        ) unread ON unread.remitente_id = u.id
        ORDER BY last_msg.fecha_envio DESC
    ";

    $stmt = $connection->prepare($query);
    $stmt->bind_param('iiii', $currentUserId, $currentUserId, $currentUserId, $currentUserId);
    $stmt->execute();
    $result = $stmt->get_result();

    $conversations = [];
    while ($row = $result->fetch_assoc()) {
        $conversations[] = [
            'contact' => normalizeUser($row),
            'last_message' => $row['ultimo_mensaje'],
            'last_at' => $row['ultima_fecha'],
            'unread' => (int) $row['no_leidos']
        ];
    }

    $connection->close();
    respondJSON('success', 'Conversaciones obtenidas', $conversations);
}

function handleListContacts($currentUserId) {
    $search = sanitizeInput($_GET['q'] ?? '');
    $connection = getDBConnection();
    ensureMessagesSchema($connection);

    if ($search !== '') {
        $like = '%' . $search . '%';
        $query = "
            SELECT id, nombre, email, tipo_usuario, foto_perfil
            FROM usuarios
            WHERE activo = TRUE
              AND id <> ?
              AND (nombre LIKE ? OR email LIKE ? OR tipo_usuario LIKE ?)
            ORDER BY tipo_usuario DESC, nombre ASC
            LIMIT 30
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('isss', $currentUserId, $like, $like, $like);
    } else {
        $query = "
            SELECT id, nombre, email, tipo_usuario, foto_perfil
            FROM usuarios
            WHERE activo = TRUE AND id <> ?
            ORDER BY tipo_usuario DESC, nombre ASC
            LIMIT 30
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('i', $currentUserId);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $contacts = [];
    while ($row = $result->fetch_assoc()) {
        $contacts[] = normalizeUser($row);
    }

    $connection->close();
    respondJSON('success', 'Contactos disponibles', $contacts);
}

function handleGetMessages($currentUserId) {
    $contactId = (int) ($_GET['contact_id'] ?? 0);
    $afterId = (int) ($_GET['after_id'] ?? 0);

    if ($contactId <= 0 || $contactId === $currentUserId) {
        respondJSON('error', 'Contacto no valido');
    }

    $connection = getDBConnection();
    ensureMessagesSchema($connection);

    $contact = getUserById($connection, $contactId);
    if (!$contact) {
        $connection->close();
        respondJSON('error', 'Contacto no encontrado');
    }

    if ($afterId > 0) {
        $query = "
            SELECT id, remitente_id, destinatario_id, contenido, leido, fecha_envio
            FROM mensajes
            WHERE id > ?
              AND ((remitente_id = ? AND destinatario_id = ?) OR (remitente_id = ? AND destinatario_id = ?))
            ORDER BY fecha_envio ASC, id ASC
            LIMIT 100
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('iiiii', $afterId, $currentUserId, $contactId, $contactId, $currentUserId);
    } else {
        $query = "
            SELECT id, remitente_id, destinatario_id, contenido, leido, fecha_envio
            FROM mensajes
            WHERE (remitente_id = ? AND destinatario_id = ?) OR (remitente_id = ? AND destinatario_id = ?)
            ORDER BY fecha_envio ASC, id ASC
            LIMIT 200
        ";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('iiii', $currentUserId, $contactId, $contactId, $currentUserId);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = normalizeMessage($row, $currentUserId);
    }

    markConversationRead($connection, $currentUserId, $contactId);
    $connection->close();

    respondJSON('success', 'Mensajes obtenidos', [
        'contact' => normalizeUser($contact),
        'messages' => $messages
    ]);
}

function handleSendMessage($currentUserId, $input) {
    $contactId = (int) ($input['contact_id'] ?? 0);
    $content = trim((string) ($input['content'] ?? ''));

    if ($contactId <= 0 || $contactId === $currentUserId) {
        respondJSON('error', 'Contacto no valido');
    }

    $contentLength = function_exists('mb_strlen') ? mb_strlen($content, 'UTF-8') : strlen($content);
    if ($content === '' || $contentLength > 2000) {
        respondJSON('error', 'El mensaje debe tener entre 1 y 2000 caracteres');
    }

    $connection = getDBConnection();
    ensureMessagesSchema($connection);

    if (!getUserById($connection, $contactId)) {
        $connection->close();
        respondJSON('error', 'Contacto no encontrado');
    }

    $safeContent = sanitizeInput($content);
    $query = "INSERT INTO mensajes (remitente_id, destinatario_id, contenido, leido) VALUES (?, ?, ?, FALSE)";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('iis', $currentUserId, $contactId, $safeContent);
    $stmt->execute();
    $messageId = $connection->insert_id;

    $query = "SELECT id, remitente_id, destinatario_id, contenido, leido, fecha_envio FROM mensajes WHERE id = ?";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $messageId);
    $stmt->execute();
    $message = $stmt->get_result()->fetch_assoc();
    $connection->close();

    respondJSON('success', 'Mensaje enviado', normalizeMessage($message, $currentUserId));
}

function handleMarkRead($currentUserId, $input) {
    $contactId = (int) ($input['contact_id'] ?? 0);
    if ($contactId <= 0) {
        respondJSON('error', 'Contacto no valido');
    }

    $connection = getDBConnection();
    ensureMessagesSchema($connection);
    markConversationRead($connection, $currentUserId, $contactId);
    $connection->close();

    respondJSON('success', 'Conversacion marcada como leida');
}

function getUserById($connection, $userId) {
    $query = "SELECT id, nombre, email, tipo_usuario, foto_perfil FROM usuarios WHERE id = ? AND activo = TRUE LIMIT 1";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function markConversationRead($connection, $currentUserId, $contactId) {
    $query = "UPDATE mensajes SET leido = TRUE WHERE remitente_id = ? AND destinatario_id = ? AND leido = FALSE";
    $stmt = $connection->prepare($query);
    $stmt->bind_param('ii', $contactId, $currentUserId);
    $stmt->execute();
}

function normalizeUser($row) {
    return [
        'id' => (int) $row['id'],
        'name' => $row['nombre'],
        'email' => $row['email'],
        'type' => $row['tipo_usuario'],
        'avatar' => $row['foto_perfil'] ?: null,
        'initials' => initials($row['nombre'])
    ];
}

function normalizeMessage($row, $currentUserId) {
    return [
        'id' => (int) $row['id'],
        'sender_id' => (int) $row['remitente_id'],
        'receiver_id' => (int) $row['destinatario_id'],
        'content' => html_entity_decode($row['contenido'], ENT_QUOTES, 'UTF-8'),
        'read' => (bool) $row['leido'],
        'sent_at' => $row['fecha_envio'],
        'mine' => (int) $row['remitente_id'] === $currentUserId
    ];
}

function initials($name) {
    $parts = preg_split('/\s+/', trim($name));
    $letters = '';
    foreach (array_slice($parts, 0, 2) as $part) {
        if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
            $letters .= mb_strtoupper(mb_substr($part, 0, 1, 'UTF-8'), 'UTF-8');
        } else {
            $letters .= strtoupper(substr($part, 0, 1));
        }
    }
    return $letters ?: 'VX';
}
?>
