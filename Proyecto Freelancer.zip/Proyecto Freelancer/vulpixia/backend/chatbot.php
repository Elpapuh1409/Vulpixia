<?php
/**
 * Backend del Chatbot - Vulpixia
 * Motor de inteligencia artificial para asistencia
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    $input = [];
}

$action = $_GET['action'] ?? $_POST['action'] ?? ($input['action'] ?? '');

switch ($action) {
    case 'send_message':
        handleSendMessage($input);
        break;
    case 'get_conversation':
        handleGetConversation($input);
        break;
    case 'save_conversation':
        handleSaveConversation($input);
        break;
    default:
        respondJSON('error', 'Acción no válida');
}

/**
 * Procesar mensaje del usuario y generar respuesta
 */
function handleSendMessage($input) {
    $userMessage = sanitize($input['message'] ?? '');
    $conversationId = sanitize($input['conversation_id'] ?? '');
    $history = $input['history'] ?? [];

    if (!$userMessage) {
        respondJSON('error', 'Mensaje vacío');
        return;
    }

    try {
        // Generar respuesta con IA
        $response = generateAIResponse($userMessage, $history);

        // Guardar en base de datos
        saveMessage($conversationId, 'user', $userMessage);
        saveMessage($conversationId, 'bot', $response['text']);

        respondJSON('success', 'Mensaje procesado', [
            'response' => $response['text'],
            'formatted' => $response['formatted'] ?? false
        ]);

    } catch (Exception $e) {
        logError('send_message', $e->getMessage());
        respondJSON('error', 'Error al procesar mensaje');
    }
}

/**
 * Generar respuesta usando IA
 * Soporta: Lógica local, OpenAI API, Google Dialogflow
 */
function generateAIResponse($userMessage, $history = []) {
    // Convertir a minúsculas para análisis
    $messageLower = normalizeMessage($userMessage);
    
    // 1. Intentar con OpenAI si está configurado
    if (getOpenAIApiKey()) {
        return generateResponseOpenAI($userMessage, $history);
    }
    
    // 2. Fallback: Lógica inteligente local
    return generateResponseLocal($messageLower, $userMessage);
}

/**
 * Generar respuesta usando OpenAI API
 */
function generateResponseOpenAI($userMessage, $history = []) {
    $apiKey = getOpenAIApiKey();

    if (!$apiKey) {
        return generateResponseLocal(normalizeMessage($userMessage), $userMessage);
    }

    try {
        // Construir historial de mensajes
        $messages = [
            [
                'role' => 'system',
                'content' => 'Eres un asistente amable de Vulpixia, una plataforma de freelancers. Ayudas a usuarios a encontrar freelancers, gestionar proyectos y responder preguntas sobre la plataforma. Sé conciso, amable y útil. Responde en español.'
            ]
        ];

        // Agregar historial reciente
        foreach (array_slice($history, -5) as $msg) {
            $messages[] = [
                'role' => $msg['sender'] === 'user' ? 'user' : 'assistant',
                'content' => $msg['content']
            ];
        }

        // Agregar mensaje actual
        $messages[] = [
            'role' => 'user',
            'content' => $userMessage
        ];

        // Llamar a OpenAI API
        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $apiKey,
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode([
                'model' => 'gpt-3.5-turbo',
                'messages' => $messages,
                'max_tokens' => 300,
                'temperature' => 0.7,
            ])
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            $data = json_decode($response, true);
            $reply = $data['choices'][0]['message']['content'] ?? '';
            
            return [
                'text' => $reply ?: 'No pude generar una respuesta.',
                'formatted' => false
            ];
        }

    } catch (Exception $e) {
        logError('openai_api', $e->getMessage());
    }

    // Fallback si falla OpenAI
    return generateResponseLocal(normalizeMessage($userMessage), $userMessage);
}

/**
 * Obtener API key desde constante o variable de entorno.
 */
function getOpenAIApiKey() {
    if (defined('OPENAI_API_KEY') && !empty(OPENAI_API_KEY)) {
        return OPENAI_API_KEY;
    }

    $envKey = getenv('OPENAI_API_KEY');
    return $envKey ?: '';
}

/**
 * Normaliza texto para detecciÃ³n de intenciones.
 */
function normalizeMessage($message) {
    $lower = function_exists('mb_strtolower') ? mb_strtolower($message, 'UTF-8') : strtolower($message);

    if (function_exists('iconv')) {
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $lower);
        if ($converted !== false) {
            $lower = $converted;
        }
    }

    return preg_replace('/[^a-z0-9\s?]/', '', $lower);
}

/**
 * Generar respuesta con lógica inteligente local
 * Análisis de intenciones y patrones
 */
function generateResponseLocal($messageLower, $originalMessage) {
    // Detectar intención del usuario
    $intention = detectIntention($messageLower);
    
    // Generar respuesta según intención
    switch ($intention) {
        case 'search_freelancer':
            return handleSearchIntention($messageLower);
        
        case 'pricing':
            return handlePricingIntention();
        
        case 'how_works':
            return handleHowWorksIntention();
        
        case 'account':
            return handleAccountIntention($messageLower);
        
        case 'projects':
            return handleProjectsIntention($messageLower);
        
        case 'support':
            return handleSupportIntention();
        
        case 'hello':
            return handleGreetingIntention();
        
        case 'thank_you':
            return handleThankYouIntention();
        
        default:
            return handleGeneralQuestion($messageLower, $originalMessage);
    }
}

/**
 * Detectar intención del usuario
 */
function detectIntention($message) {
    if (preg_match('/\b(buscar|encontrar|freelancer|programador|disenador|desarrollador|editor|traductor|redactor|necesito)\b/', $message)) {
        return 'search_freelancer';
    }

    if (preg_match('/\b(precio|costo|planes|membresia|suscripcion|premium|tarifa|gratis)\b/', $message) || strpos($message, 'cuanto cuesta') !== false) {
        return 'pricing';
    }

    if (strpos($message, 'como funciona') !== false || strpos($message, 'como se usa') !== false || preg_match('/\b(tutorial|guia|pasos|proceso)\b/', $message)) {
        return 'how_works';
    }

    if (preg_match('/\b(cuenta|perfil|registro|contrasena|login|acceso|registrarse|usuario)\b/', $message)) {
        return 'account';
    }

    if (preg_match('/\b(hola|hi|hey)\b/', $message) || strpos($message, 'buenos dias') !== false || strpos($message, 'que tal') !== false || strpos($message, 'como estas') !== false) {
        return 'hello';
    }
    // Palabras clave por intención
    $intentions = [
        'search_freelancer' => ['buscar', 'encontrar', 'freelancer', 'programador', 'diseñador', 'desarrollador', 'editor', 'camarógrafo', 'traductor', 'redactor', 'necesito', 'quiero', 'buscando'],
        'pricing' => ['precio', 'costo', 'planes', 'membresía', 'suscripción', 'cuánto cuesta', 'gratis', 'premium', 'profesional', 'empresarial', 'tarifa'],
        'how_works' => ['cómo funciona', 'cómo se usa', 'tutorial', 'guía', 'explicame', 'proceso', 'pasos', 'funcionamiento'],
        'account' => ['cuenta', 'perfil', 'registro', 'contraseña', 'login', 'acceso', 'registrarse', 'crear cuenta', 'usuario'],
        'projects' => ['proyecto', 'propuesta', 'enviar propuesta', 'crear proyecto', 'proyecto nuevo', 'trabajo'],
        'support' => ['ayuda', 'soporte', 'contacto', 'problema', 'error', 'no funciona', 'reportar', 'incidencia'],
        'hello' => ['hola', 'hi', 'hey', 'buenos días', 'buenas tardes', 'buenas noches', 'qué tal', '¿cómo estás?'],
        'thank_you' => ['gracias', 'grazie', 'thank you', 'merci', 'muchas gracias'],
    ];

    // Buscar coincidencias
    foreach ($intentions as $intent => $keywords) {
        foreach ($keywords as $keyword) {
            if (strpos($message, $keyword) !== false) {
                return $intent;
            }
        }
    }

    return 'general';
}

/**
 * Manejo: Búsqueda de freelancers
 */
function handleSearchIntention($message) {
    // Extraer categoría mencionada
    $categories = ['programacion', 'diseno', 'video', 'marketing', 'redaccion', 'traduccion', 'fotografia', 'animacion', 'musica'];
    $category = '';
    
    foreach ($categories as $cat) {
        if (strpos($message, $cat) !== false) {
            $category = $cat;
            break;
        }
    }

    $categoryText = $category ? " en la categoría de $category" : '';
    
    return [
        'text' => "¡Excelente! Puedo ayudarte a encontrar el freelancer perfecto$categoryText. 🔍\n\n" .
                 "Aquí están nuestros mejores opciones:\n" .
                 "• <a href='pages/ranking.html' target='_blank'>Ver ranking de freelancers</a>\n" .
                 "• <a href='index.html#freelancers' target='_blank'>Explorar perfiles destacados</a>\n\n" .
                 "¿Tienes algún requisito específico que deba saber?",
        'formatted' => true
    ];
}

/**
 * Manejo: Información de precios
 */
function handlePricingIntention() {
    return [
        'text' => "💎 **Planes de Vulpixia:**\n\n" .
                 "📌 **Básico** - Gratis\n" .
                 "Para comenzar con 3 proyectos activos\n\n" .
                 "⭐ **Profesional** - $9.99/mes\n" .
                 "20 proyectos, 50 propuestas, 10GB almacenamiento\n\n" .
                 "✨ **Premium** - $24.99/mes\n" .
                 "100 proyectos, 500 propuestas, 50GB almacenamiento\n\n" .
                 "👑 **Empresarial** - $99.99/mes\n" .
                 "Límites ilimitados, soporte dedicado\n\n" .
                 "<a href='pages/memberships.html' target='_blank'>Ver todos los planes →</a>",
        'formatted' => true
    ];
}

/**
 * Manejo: Cómo funciona
 */
function handleHowWorksIntention() {
    return [
        'text' => "📋 **Cómo funciona Vulpixia:**\n\n" .
                 "1️⃣ **Regístrate** como cliente o freelancer\n" .
                 "2️⃣ **Publica** tu proyecto o busca oportunidades\n" .
                 "3️⃣ **Conecta** con talentos ideales\n" .
                 "4️⃣ **Colabora** en la plataforma\n" .
                 "5️⃣ **Paga** seguro cuando estés satisfecho\n" .
                 "6️⃣ **Deja reseña** y construye tu reputación\n\n" .
                 "<a href='#como-funciona' target='_blank'>Ver guía completa →</a>",
        'formatted' => true
    ];
}

/**
 * Manejo: Información de cuenta
 */
function handleAccountIntention($message) {
    return [
        'text' => "👤 **Gestión de Cuenta:**\n\n" .
                 "• <a href='pages/register.html' target='_blank'>Crear nueva cuenta</a>\n" .
                 "• <a href='pages/login.html' target='_blank'>Iniciar sesión</a>\n" .
                 "• <a href='pages/ranking.html' target='_blank'>Ver tu ranking</a>\n\n" .
                 "¿Necesitas ayuda con algún aspecto específico de tu cuenta?",
        'formatted' => true
    ];
}

/**
 * Manejo: Información de proyectos
 */
function handleProjectsIntention($message) {
    return [
        'text' => "💼 **Gestión de Proyectos:**\n\n" .
                 "Si eres **cliente**:\n" .
                 "• Publica tu proyecto con detalles claros\n" .
                 "• Recibe propuestas de freelancers calificados\n" .
                 "• Elige el mejor y colabora en la plataforma\n\n" .
                 "Si eres **freelancer**:\n" .
                 "• Explora proyectos disponibles\n" .
                 "• Envía propuestas personalizadas\n" .
                 "• Completa el trabajo y obtén pagos seguros\n\n" .
                 "¿En qué puedo ayudarte más específicamente?",
        'formatted' => true
    ];
}

/**
 * Manejo: Soporte
 */
function handleSupportIntention() {
    return [
        'text' => "📞 **Contáctanos:**\n\n" .
                 "• Email: support@vulpixia.com\n" .
                 "• Teléfono: +1 (800) 123-4567\n" .
                 "• Chat: 24/7 disponible\n\n" .
                 "También puedes revisar:\n" .
                 "• <a href='pages/legal/terms.html' target='_blank'>Términos de Servicio</a>\n" .
                 "• <a href='pages/legal/privacy.html' target='_blank'>Política de Privacidad</a>\n\n" .
                 "¿Hay algún problema específico que pueda resolver?",
        'formatted' => true
    ];
}

/**
 * Manejo: Saludo
 */
function handleGreetingIntention() {
    $greetings = [
        "¡Hola! 👋 Bienvenido a Vulpixia. ¿En qué puedo ayudarte?",
        "¡Hola! 🦊 Soy tu asistente de IA. ¿Qué necesitas?",
        "¡Qué tal! 😊 Estoy aquí para ayudarte con cualquier pregunta.",
        "¡Bienvenido! 🎉 ¿Cómo te puedo asistir hoy?"
    ];
    
    return [
        'text' => $greetings[array_rand($greetings)],
        'formatted' => false
    ];
}

/**
 * Manejo: Agradecimiento
 */
function handleThankYouIntention() {
    $responses = [
        "¡De nada! 😊 Estoy aquí cuando me necesites.",
        "¡Con gusto! 🦊 ¿Hay algo más en lo que pueda ayudarte?",
        "¡Feliz de ayudar! 💪 No dudes en preguntar.",
        "¡Tu confianza es lo más importante para nosotros! 💜"
    ];
    
    return [
        'text' => $responses[array_rand($responses)],
        'formatted' => false
    ];
}

/**
 * Manejo: Preguntas generales
 */
function handleGeneralQuestion($messageLower, $originalMessage) {
    // Respuestas inteligentes a preguntas comunes
    $responses = [
        'es seguro' => "✅ Sí, Vulpixia es 100% seguro. Usamos encriptación SSL/TLS, pagos asegurados y verificación de usuarios.",
        'es gratis' => "💰 Vulpixia tiene un plan gratuito, pero también ofrecemos planes premium con más funcionalidades.",
        'cuánto tiempo' => "⏰ Los tiempos varían según el proyecto, pero nuestros freelancers son conocidos por su eficiencia.",
        'quién eres' => "🦊 Soy el Asistente de IA de Vulpixia, aquí para ayudarte 24/7.",
        'top 1' => "👑 Carlos Mendoza es nuestro freelancer #1 con 847 proyectos completados y 5.0 estrellas.",
    ];

    // Buscar respuesta predefinida
    foreach ($responses as $keyword => $response) {
        if (strpos($messageLower, $keyword) !== false) {
            return ['text' => $response, 'formatted' => false];
        }
    }

    // Respuesta genérica inteligente
    $genericResponses = [
        "Esa es una excelente pregunta. ¿Podrías darme más detalles para ayudarte mejor?",
        "Interesante consulta. 🤔 ¿Hay algo específico que quieras saber sobre Vulpixia?",
        "Entiendo. Para ayudarte mejor, ¿podrías ser un poco más específico?",
        "Buena pregunta. Puedo ayudarte con freelancers, proyectos, precios y más. ¿En qué estás interesado?"
    ];

    return [
        'text' => $genericResponses[array_rand($genericResponses)],
        'formatted' => false
    ];
}

/**
 * Guardar mensaje en base de datos
 */
function saveMessage($conversationId, $sender, $message) {
    try {
        if (!$conversationId) {
            return;
        }

        $connection = getChatbotDBConnection();
        if (!$connection) {
            return;
        }
        
        // Si no existe tabla, crearla
        $query = "CREATE TABLE IF NOT EXISTS chat_conversaciones (
            id INT PRIMARY KEY AUTO_INCREMENT,
            conversation_id VARCHAR(255) NOT NULL,
            usuario_id INT,
            sender ENUM('user', 'bot') NOT NULL,
            mensaje LONGTEXT NOT NULL,
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_conversation (conversation_id),
            INDEX idx_fecha (fecha)
        )";
        $connection->query($query);
        
        $usuarioId = isAuthenticated() ? (int) getCurrentUser() : null;

        if ($usuarioId) {
            $query = "INSERT INTO chat_conversaciones (conversation_id, usuario_id, sender, mensaje) VALUES (?, ?, ?, ?)";
            $stmt = $connection->prepare($query);
            $stmt->bind_param('siss', $conversationId, $usuarioId, $sender, $message);
        } else {
            $query = "INSERT INTO chat_conversaciones (conversation_id, sender, mensaje) VALUES (?, ?, ?)";
            $stmt = $connection->prepare($query);
            $stmt->bind_param('sss', $conversationId, $sender, $message);
        }

        $stmt->execute();
        
        $connection->close();
    } catch (Exception $e) {
        logError('save_message', $e->getMessage());
    }
}

/**
 * ConexiÃ³n opcional para el chat: si MySQL no estÃ¡ listo, el bot igual responde.
 */
function getChatbotDBConnection() {
    mysqli_report(MYSQLI_REPORT_OFF);
    $connection = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

    if ($connection->connect_errno) {
        return null;
    }

    $connection->set_charset('utf8mb4');
    return $connection;
}

/**
 * Obtener conversación
 */
function handleGetConversation($input) {
    $conversationId = sanitize($input['conversation_id'] ?? '');
    
    if (!$conversationId) {
        respondJSON('error', 'ID de conversación no válido');
        return;
    }

    try {
        $connection = getChatbotDBConnection();

        if (!$connection) {
            respondJSON('success', 'ConversaciÃ³n local no disponible en base de datos', []);
            return;
        }
        
        $query = "SELECT sender, mensaje, fecha FROM chat_conversaciones WHERE conversation_id = ? ORDER BY fecha ASC LIMIT 50";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('s', $conversationId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $messages = [];
        while ($row = $result->fetch_assoc()) {
            $messages[] = [
                'sender' => $row['sender'],
                'content' => $row['mensaje'],
                'timestamp' => $row['fecha']
            ];
        }
        
        respondJSON('success', 'Conversación obtenida', $messages);
        $connection->close();
        
    } catch (Exception $e) {
        logError('get_conversation', $e->getMessage());
        respondJSON('error', 'Error al obtener conversación');
    }
}

/**
 * Guardar conversación
 */
function handleSaveConversation($input) {
    if (!isAuthenticated()) {
        respondJSON('error', 'No autenticado');
        return;
    }

    $conversationId = sanitize($input['conversation_id'] ?? '');
    
    try {
        $connection = getChatbotDBConnection();

        if (!$connection) {
            respondJSON('error', 'Base de datos no disponible');
            return;
        }

        $usuario_id = (int) getCurrentUser();
        
        // Actualizar usuario en conversación
        $query = "UPDATE chat_conversaciones SET usuario_id = ? WHERE conversation_id = ?";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('is', $usuario_id, $conversationId);
        $stmt->execute();
        
        respondJSON('success', 'Conversación guardada');
        $connection->close();
        
    } catch (Exception $e) {
        logError('save_conversation', $e->getMessage());
        respondJSON('error', 'Error al guardar conversación');
    }
}
?>
