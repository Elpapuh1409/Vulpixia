<?php
/**
 * Archivo index.php en backend
 * Previene el acceso directo al directorio
 */

header('HTTP/1.0 403 Forbidden');
die('Acceso denegado.');
?>
