# API Documentation - Vulpixia

Documentación completa de los endpoints de la API REST de Vulpixia.

## Base URL
```
http://localhost/vulpixia/backend/handlers.php
```

## Autenticación

La mayoría de endpoints protegidos requieren una sesión activa iniciada con `login`.

## Endpoints Disponibles

### 1. AUTENTICACIÓN

#### 1.1 Registro de Usuario
**Endpoint:** `POST /handlers.php?action=register`

**Campos requeridos:**
```json
{
  "nombre": "string",
  "email": "string",
  "password": "string",
  "confirmPassword": "string",
  "tipo_usuario": "cliente | freelancer"
}
```

**Campos adicionales para freelancer:**
```json
{
  "categoria": "string",
  "habilidades": "string (separadas por comas)",
  "experiencia": "string",
  "tarifa": "number",
  "portafolio": "string (URL)"
}
```

**Campos adicionales para cliente:**
```json
{
  "tipo_proyecto": "string"
}
```

**Respuesta exitosa (200):**
```json
{
  "status": "success",
  "message": "Cuenta creada exitosamente",
  "data": {
    "user_id": 1,
    "nombre": "Carlos Mendoza",
    "tipo_usuario": "freelancer"
  }
}
```

**Respuesta error (400):**
```json
{
  "status": "error",
  "message": "El correo electrónico ya está registrado",
  "data": {}
}
```

#### 1.2 Login
**Endpoint:** `POST /handlers.php?action=login`

**Campos requeridos:**
```json
{
  "email": "string",
  "password": "string"
}
```

**Respuesta exitosa (200):**
```json
{
  "status": "success",
  "message": "Login exitoso",
  "data": {
    "user_id": 1,
    "nombre": "Carlos Mendoza",
    "email": "carlos@example.com",
    "tipo_usuario": "freelancer"
  }
}
```

#### 1.3 Logout
**Endpoint:** `GET /handlers.php?action=logout`

**Respuesta:**
```json
{
  "status": "success",
  "message": "Sesión cerrada",
  "data": {}
}
```

---

### 2. FREELANCERS

#### 2.1 Búsqueda de Freelancers
**Endpoint:** `GET /handlers.php?action=search_freelancers`

**Parámetros:**
- `q` (string, opcional): Término de búsqueda
- `category` (string, opcional): Categoría a filtrar
- `page` (number, opcional): Número de página (default: 1)

**Ejemplos:**
```
GET /handlers.php?action=search_freelancers&q=react
GET /handlers.php?action=search_freelancers&category=programacion
GET /handlers.php?action=search_freelancers&q=react&category=programacion&page=1
```

**Respuesta exitosa:**
```json
{
  "status": "success",
  "message": "Búsqueda completada",
  "data": {
    "freelancers": [
      {
        "id": 1,
        "nombre": "Carlos Mendoza",
        "email": "carlos@example.com",
        "categoria": "programacion",
        "habilidades": "React, Node.js",
        "tarifa": 50,
        "portafolio": "https://carlosportafolio.com",
        "calificacion": 4.9,
        "proyectos_completados": 87
      }
    ],
    "total": 1,
    "page": 1
  }
}
```

#### 2.2 Obtener Perfil de Freelancer
**Endpoint:** `GET /handlers.php?action=get_freelancer&id=1`

**Parámetros:**
- `id` (number, requerido): ID del freelancer

**Respuesta:**
```json
{
  "status": "success",
  "message": "Datos del freelancer obtenidos",
  "data": {
    "id": 1,
    "nombre": "Carlos Mendoza",
    "email": "carlos@example.com",
    "foto_perfil": "url_foto",
    "descripcion": "Descripción del freelancer",
    "ubicacion": "Colombia",
    "calificacion_promedio": 4.9,
    "verificado": true
  }
}
```

---

### 3. PROYECTOS

#### 3.1 Crear Proyecto
**Endpoint:** `POST /handlers.php?action=create_project`

**Requerimientos:** Usuario autenticado con tipo_usuario = "cliente"

**Campos requeridos:**
```json
{
  "titulo": "string",
  "descripcion": "string",
  "categoria": "string",
  "presupuesto": "number",
  "fecha_entrega": "date (YYYY-MM-DD)"
}
```

**Respuesta exitosa:**
```json
{
  "status": "success",
  "message": "Proyecto creado exitosamente",
  "data": {
    "project_id": 5,
    "titulo": "Desarrollo de aplicación React"
  }
}
```

---

### 4. CONTACTO

#### 4.1 Enviar Mensaje de Contacto
**Endpoint:** `POST /handlers.php?action=contact`

**Campos requeridos:**
```json
{
  "nombre": "string",
  "email": "string",
  "mensaje": "string (mínimo 10 caracteres)"
}
```

**Respuesta exitosa:**
```json
{
  "status": "success",
  "message": "Mensaje enviado exitosamente",
  "data": {}
}
```

---

### 5. PERFIL

#### 5.1 Actualizar Perfil
**Endpoint:** `POST /handlers.php?action=update_profile`

**Requerimientos:** Usuario autenticado

**Campos:**
```json
{
  "nombre": "string"
}
```

**Respuesta:**
```json
{
  "status": "success",
  "message": "Perfil actualizado exitosamente",
  "data": {}
}
```

---

## Códigos de Error

| Código | Mensaje | Descripción |
|--------|---------|------------|
| 400 | Método no permitido | Se utilizó un método HTTP incorrecto |
| 400 | Acción no válida | La acción solicitada no existe |
| 401 | Debes estar autenticado | Se requiere iniciar sesión |
| 403 | Acceso denegado | No tienes permisos para esta acción |
| 404 | No encontrado | El recurso solicitado no existe |
| 422 | Validación fallida | Los datos proporcionados son inválidos |
| 500 | Error de servidor | Error interno del servidor |

---

## Validaciones

### Email
- Debe ser un email válido
- Debe ser único en la base de datos
- No puede estar vacío

### Contraseña
- Mínimo 6 caracteres
- Debe coincidir con la confirmación
- Se hashea con bcrypt

### Mensaje de Contacto
- Mínimo 10 caracteres
- No puede estar vacío

### Proyecto
- El usuario debe ser tipo "cliente"
- Todos los campos son requeridos
- La fecha debe ser futura

---

## Headers Recomendados

Cuando hagas requests a la API, incluye estos headers:

```
Content-Type: application/json
Accept: application/json
```

---

## Ejemplos con cURL

### Registro
```bash
curl -X POST http://localhost/vulpixia/backend/handlers.php?action=register \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Carlos Mendoza",
    "email": "carlos@example.com",
    "password": "password123",
    "confirmPassword": "password123",
    "tipo_usuario": "freelancer",
    "categoria": "programacion",
    "habilidades": "React, Node.js",
    "experiencia": "5",
    "tarifa": "50",
    "portafolio": "https://example.com"
  }'
```

### Login
```bash
curl -X POST http://localhost/vulpixia/backend/handlers.php?action=login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "carlos@example.com",
    "password": "password123"
  }'
```

### Búsqueda de Freelancers
```bash
curl "http://localhost/vulpixia/backend/handlers.php?action=search_freelancers&q=react"
```

### Crear Proyecto
```bash
curl -X POST http://localhost/vulpixia/backend/handlers.php?action=create_project \
  -H "Content-Type: application/json" \
  -d '{
    "titulo": "Desarrollo web",
    "descripcion": "Necesito un sitio web responsivo",
    "categoria": "programacion",
    "presupuesto": 500,
    "fecha_entrega": "2026-06-15"
  }' \
  -b "PHPSESSID=tu_session_id"
```

---

## Consideraciones de Seguridad

1. **HTTPS:** Siempre usa HTTPS en producción
2. **Rate Limiting:** Implementar límite de requests
3. **CORS:** Configurar CORS si es necesario
4. **Validación:** Todos los inputs se validan en servidor
5. **Sanitización:** Se sanitizan todos los datos
6. **Sesiones:** Las sesiones expiran automáticamente

---

## Próximas Versiones de API

- v1.1: Paginación mejorada
- v1.2: Filtros avanzados
- v1.3: Webhooks
- v2.0: OAuth 2.0

---

**Última actualización:** 2026-05-05
**Versión:** 1.0
