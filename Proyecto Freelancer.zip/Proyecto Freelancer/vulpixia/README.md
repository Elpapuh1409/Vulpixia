# 🦊 Vulpixia - Marketplace de Freelancers

Vulpixia es una plataforma moderna de marketplace de freelancers diseñada para conectar clientes con profesionales talentosos en diversas categorías.

## ✨ Características Principales

### Para Clientes
- 🔍 Búsqueda avanzada de freelancers por categoría y habilidades
- 📝 Publicación de proyectos con presupuestos flexibles
- 💬 Comunicación directa con freelancers
- ⭐ Sistema de reseñas y calificaciones
- 📊 Seguimiento de proyectos en tiempo real

### Para Freelancers
- 👤 Perfiles profesionales con portafolio
- 📍 Visibilidad en categorías específicas
- 📈 Sistema de calificaciones y reseñas
- 💰 Gestión de ofertas y proyectos
- 🎯 Oportunidades de trabajo verificadas

## 🎨 Diseño Visual

**Paleta de Colores:**
- 🟣 Morado Principal: #8B5CF6
- 💗 Rosa Secundario: #EC4899
- 🌙 Azul Oscuro: #0F172A
- ⚪ Blanco Base: #FFFFFF
- ✨ Acentos Neón: Rosa/Azul

**Características del Diseño:**
- Interfaz moderna y profesional
- Diseño responsivo (mobile, tablet, desktop)
- Animaciones suaves y transiciones
- Gradientes sofisticados
- Iconografía clara

## 📁 Estructura del Proyecto

```
vulpixia/
├── index.html                 # Página de inicio
├── assets/
│   ├── css/
│   │   └── style.css         # Estilos principales
│   ├── js/
│   │   └── script.js         # JavaScript interactivo
│   └── images/               # Imágenes y assets
├── pages/
│   ├── login.html            # Página de login
│   ├── register.html         # Página de registro
│   └── freelancer-profile.html # Perfil de freelancer
├── backend/
│   ├── config.php            # Configuración
│   ├── database.php          # Funciones de BD
│   ├── handlers.php          # Manejadores de formularios
│   └── database.sql          # Script SQL
└── README.md                 # Este archivo
```

## 🚀 Instalación y Configuración

### Requisitos Previos
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Servidor web (Apache, Nginx, etc.)
- Navegador moderno

### Paso 1: Descarga el Proyecto
```bash
git clone https://github.com/tu-usuario/vulpixia.git
cd vulpixia
```

### Paso 2: Configurar la Base de Datos

1. Abre tu cliente MySQL (phpMyAdmin, MySQL Workbench, etc.)
2. Importa el archivo `backend/database.sql`:
   ```sql
   source backend/database.sql;
   ```
   O copiar y pegar el contenido del archivo SQL

### Paso 3: Configurar el Conexión a BD

Edita `backend/config.php` con tus credenciales:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'tu_usuario');
define('DB_PASS', 'tu_contraseña');
define('DB_NAME', 'vulpixia_db');
```

### Paso 4: Levantar el Servidor

**Con PHP incorporado:**
```bash
php -S localhost:8000
```

**Con Apache:**
- Coloca la carpeta en `htdocs/` (XAMPP) o en la raíz del servidor
- Accede a `http://localhost/vulpixia/`

## 📋 Categorías de Servicios

1. 💻 Programación
2. 🎨 Diseño Gráfico
3. 🎬 Edición de Video
4. 📊 Marketing Digital
5. ✍️ Redacción
6. 🌍 Traducción
7. 📸 Fotografía
8. ✨ Animación
9. 🌐 Desarrollo Web
10. 📱 Desarrollo Móvil
11. 🤖 Inteligencia Artificial
12. 🔧 Soporte Técnico
13. 🎵 Música y Audio
14. 👥 Community Manager
15. 🤖 Asistente Virtual
16. 🎭 Arte e Ilustración

## 🔑 Funcionalidades Backend

### Autenticación
- Registro de usuarios (cliente/freelancer)
- Login con validación segura
- Gestión de sesiones
- Recuperación de contraseña (preparada)

### Gestión de Freelancers
- Búsqueda por categoría
- Búsqueda por habilidades
- Filtrado avanzado
- Perfiles con portafolio

### Gestión de Proyectos
- Creación de proyectos
- Seguimiento de estado
- Propuestas de freelancers
- Sistema de pagos (estructura)

### Sistema de Reseñas
- Calificación de 1-5 estrellas
- Comentarios y feedback
- Historial de reseñas

### Mensajería
- Mensajes entre usuarios
- Adjuntos de archivos
- Historial de conversaciones

## 📱 Páginas Incluidas

### Home (index.html)
- Hero con call-to-action
- Sección "¿Quién eres?"
- Grid de categorías
- Freelancers destacados
- Cómo funciona
- Formulario de contacto
- Footer

### Login (pages/login.html)
- Formulario con validación
- Opción Google (estructura)
- Enlace a registro
- Recuperar contraseña

### Registro (pages/register.html)
- Tipo de usuario (cliente/freelancer)
- Campos dinámicos según tipo
- Validación en tiempo real
- Indicador de fortaleza de contraseña

### Perfil de Freelancer (pages/freelancer-profile.html)
- Información profesional
- Habilidades y experiencia
- Portafolio (6 proyectos)
- Reseñas de clientes
- Opciones de contratación

## 🛠️ API Endpoints (Backend)

### Autenticación
- `POST /backend/handlers.php?action=register` - Registro
- `POST /backend/handlers.php?action=login` - Login
- `GET /backend/handlers.php?action=logout` - Logout

### Freelancers
- `GET /backend/handlers.php?action=search_freelancers` - Buscar
- `GET /backend/handlers.php?action=get_freelancer&id=1` - Obtener perfil

### Proyectos
- `POST /backend/handlers.php?action=create_project` - Crear proyecto
- `GET /backend/handlers.php?action=get_project&id=1` - Obtener proyecto

### Contacto
- `POST /backend/handlers.php?action=contact` - Enviar mensaje

## 🔐 Seguridad

Implementadas características de seguridad:
- Hashing de contraseñas con bcrypt
- Validación de inputs (sanitización)
- Protección CSRF (preparada)
- Sesiones seguras
- Prepared Statements (SQL Injection prevention)
- Validación de email
- Control de acceso

## 📚 Tecnologías Utilizadas

- **Frontend:**
  - HTML5 semántico
  - CSS3 (variables, gradientes, flexbox, grid)
  - JavaScript vanilla (ES6+)
  - Font Awesome (iconografía)

- **Backend:**
  - PHP 7.4+
  - MySQL 5.7+
  - Programación orientada a objetos
  - REST API JSON

- **Herramientas:**
  - Git para control de versiones
  - phpMyAdmin para gestión de BD

## 📊 Próximas Mejoras

- [ ] Sistema de pagos integrado (Stripe, PayPal)
- [ ] Notificaciones en tiempo real
- [ ] Chat en vivo
- [ ] Aplicación móvil (React Native)
- [ ] Sistema de calificación avanzado
- [ ] Análisis y reportes
- [ ] Integración con Google Maps
- [ ] Autenticación OAuth
- [ ] Webhooks
- [ ] API pública documentada

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la licencia MIT. Ver `LICENSE` para más detalles.

## 📞 Soporte

¿Preguntas o problemas? Crea un issue en el repositorio.

## 👨‍💻 Autor

Desarrollado con ❤️ por tu equipo de desarrollo

## 🎯 Roadmap

### Version 1.0 (Actual)
- ✅ Diseño responsivo
- ✅ Sistema de autenticación básico
- ✅ Búsqueda de freelancers
- ✅ Perfiles profesionales
- ✅ Estructura de base de datos

### Version 1.1 (Próxima)
- [ ] Sistema de pagos
- [ ] Notificaciones por email
- [ ] Dashboard de usuario
- [ ] Filtros avanzados

### Version 2.0 (Futuro)
- [ ] App móvil
- [ ] Video llamadas integradas
- [ ] IA para recomendaciones
- [ ] Análisis de datos

---

**Vulpixia - Conectando talento con oportunidades** 🦊✨

Versión 1.0 | 2026
